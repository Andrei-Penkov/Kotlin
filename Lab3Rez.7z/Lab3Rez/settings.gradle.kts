rootProject.name = "ApplicationTemplate"
