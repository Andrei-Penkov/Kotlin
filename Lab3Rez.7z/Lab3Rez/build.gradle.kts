plugins {
    kotlin("jvm") version "2.0.20"
    id("ru.yarsu.json-project-properties")
    id("org.jlleitschuh.gradle.ktlint") version "12.1.1"
}

group = "ru.ac.uniyar"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    testImplementation(kotlin("test"))
    implementation("org.jcommander:jcommander:2.0")
    implementation("org.http4k:http4k-core:5.32.0.0")
    implementation("org.http4k:http4k-client-apache:5.32.0.0")
    implementation("org.http4k:http4k-server-netty:5.32.0.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("org.json:json:20231013")
    implementation("com.fasterxml.jackson.module:jackson-module-kotlin:2.17.2")
    implementation("com.google.code.gson:gson:2.8.9")
    implementation("org.slf4j:slf4j-simple:2.0.16")
    implementation("org.slf4j:slf4j-api:2.0.16")
    implementation("org.http4k:http4k-format-jackson:5.37.1.1")
}

tasks.test {
    useJUnitPlatform()
}

kotlin {
    jvmToolchain(21)
}

ktlint {
    version.set("1.3.1")
}
