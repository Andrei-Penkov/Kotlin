package ru.yarsu

import com.beust.jcommander.Parameter
import com.beust.jcommander.Parameters
import com.fasterxml.jackson.core.JsonFactory
import com.fasterxml.jackson.core.JsonFactoryBuilder
import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.util.DefaultIndenter
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.UUID
import kotlin.system.exitProcess

@Parameters(separators = "=")
class Args {
    @Parameter(names = ["--equipment-file"], description = "Input file")
    var inputFile: String? = null

    @Parameter(names = ["--log-file"], description = "Input reg")
    var inputReg: String? = null

    @Parameter(names = ["--users-file"], description = "Input users")
    var inputUser: String? = null

    @Parameter(names = ["--port"], description = "Input port")
    var inputPort: String? = null
}

@Parameters(commandNames = ["list"], separators = "=")
class ListCommand {
    @Parameter(names = ["--equipment-file"], description = "Input file", required = true)
    var inputFile: String? = null

    fun list() {
        val list = createdList(File(inputFile.toString()))
        val outputList = list.sortedWith(compareBy({ it.Category }, { it.Id }))
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val outputGenerator: JsonGenerator = factory.createGenerator(System.out)
        val printer = DefaultPrettyPrinter()
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        with(outputGenerator) {
            if (outputList.isEmpty()) {
                writeStartObject()
                writeFieldName("equipment")
                writeStartArray()
                writeEndArray()
                outputGenerator.close()
                return
            }
            writeStartObject()
            writeFieldName("equipment")
            writeStartArray()
            for (i in outputList) {
                writeStartObject()
                writeFieldName("Id")
                writeString(i.Id.toString())
                writeFieldName("Equipment")
                writeString(i.Equipment)
                writeFieldName("IsUsed")
                writeBoolean(i.IsUsed)
                writeEndObject()
            }
            writeEndArray()
        }
        outputGenerator.close()
    }
}

@Parameters(commandNames = ["show-equipment"], separators = "=")
class ShowEquipment {
    @Parameter(names = ["--equipment-id"], required = true)
    var equipmentId: String? = null

    @Parameter(names = ["--equipment-file"], description = "Input file", required = true)
    var inputFile: String? = null

    fun showEquipment() {
        val list = createdList(File(inputFile.toString()))
        if (list.isEmpty()) {
            throw IllegalArgumentException()
        }
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val outputGenerator: JsonGenerator = factory.createGenerator(System.out)
        val printer = DefaultPrettyPrinter()
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        with(outputGenerator) {
            writeStartObject()
            writeFieldName("equipment-id")
            writeString(equipmentId)
            writeFieldName("equipment")
            for (i in list) {
                if (i.Id.equals(UUID.fromString(equipmentId))) {
                    writeStartObject()
                    writeFieldName("Id")
                    writeString(i.Id.toString())
                    writeFieldName("Equipment")
                    writeString(i.Equipment)
                    writeFieldName("Category")
                    writeString(i.Category)
                    writeFieldName("GuaranteeDate")
                    writeString(i.GuaranteeDate.toString())
                    writeFieldName("IsUsed")
                    writeBoolean(i.IsUsed)
                    writeFieldName("Price")
                    writeNumber(i.Price)
                    writeFieldName("Location")
                    writeString(i.Location)
                    writeFieldName("ResponsiblePerson")
                    writeString(i.ResponsiblePerson)
                    writeFieldName("User")
                    writeString(i.User)
                    writeEndObject()
                }
            }
        }
        outputGenerator.close()
    }
}

@Parameters(commandNames = ["list-unused-equipment"], separators = "=")
class ListUnusedEquipment {
    @Parameter(names = ["--category"], required = false)
    var text: String? = null

    @Parameter(names = ["--equipment-file"], description = "Input file", required = true)
    var inputFile: String? = null

    fun listUnusedEquipment() {
        val list = createdList(File(inputFile.toString()))
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val list1 = mutableListOf<ItemC>()
        if (text != null) {
            for (i in text.toString().trim().split(",")) {
                when (i.lowercase()) {
                    "монитор" -> continue
                    "пк" -> continue
                    "телефон" -> continue
                    "принтер" -> continue
                    "другое" -> continue
                    " " -> continue
                    "" -> continue
                    "," -> continue
                    else -> {
                        throw IllegalAccessException()
                    }
                }
            }
        }
        val outputGenerator: JsonGenerator = factory.createGenerator(System.out)
        outputGenerator.prettyPrinter = DefaultPrettyPrinter()
        var count = 0
        val rez = list.sortedWith(compareBy({ it.Category }, { it.Id }))
        with(outputGenerator) {
            writeStartObject()
            if (text != null) {
                writeFieldName("category")
                writeString(text)
                for (i in text!!.trim().split(",")) {
                    if (i.length > 0) {
                        for (j in rez) {
                            if (j.IsUsed == false && j.Category.lowercase() == i.lowercase()) {
                                count++
                                list1.add(j)
                            }
                        }
                    } else {
                        for (j in rez) {
                            if (j.IsUsed == false && j.Category.lowercase() == i.lowercase()) {
                                count++
                                list1.add(j)
                            }
                        }
                    }
                }
            } else {
                writeFieldName("category")
                writeString("")
                for (i in rez) {
                    if (i.IsUsed == false) {
                        count++
                        list1.add(i)
                    }
                }
            }
            writeFieldName("equipment")
            writeStartArray()
            for (i in list1) {
                writeStartObject()
                writeFieldName("Id")
                writeString(i.Id.toString())
                writeFieldName("Equipment")
                writeString(i.Equipment)
                writeEndObject()
            }
            writeEndArray()
        }
        outputGenerator.close()
    }
}

@Parameters(commandNames = ["list-time"], separators = "=")
class ListTime {
    @Parameter(names = ["--time"], required = true)
    var time: String? = null

    @Parameter(names = ["--equipment-file"], description = "Input file", required = true)
    var inputFile: String? = null

    fun listTime() {
        val list = createdList(File(inputFile.toString()))
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val outputGenerator: JsonGenerator = factory.createGenerator(System.out)
        outputGenerator.prettyPrinter = DefaultPrettyPrinter()
        val list1 = mutableListOf<ItemC>()
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        for (i in list) {
            if (time!!.split("T")[1].equals(null)) {
                throw IllegalAccessException()
            }
            if (i.GuaranteeDate <= (LocalDate.parse(time!!.split("T")[0], formatter))) {
                list1.add(i)
            }
        }
        val list2 = list1.sortedWith(compareBy({ it.Category }, { it.Id }))
        with(outputGenerator) {
            writeStartObject()
            writeFieldName("time")
            writeString(time)
            writeFieldName("equipment")
            writeStartArray()
            for (i in list2) {
                writeStartObject()
                writeFieldName("Id")
                writeString(i.Id.toString())
                writeFieldName("Equipment")
                writeString(i.Equipment)
                writeFieldName("GuaranteeDate")
                writeString(i.GuaranteeDate.toString())
                writeEndObject()
            }
            writeEndArray()
        }
        outputGenerator.close()
    }
}

@Parameters(commandNames = ["statistic"], separators = "=")
class Statistic {
    @Parameter(names = ["--by-type"], required = true)
    var text: String? = null

    @Parameter(names = ["--equipment-file"], description = "Input file", required = true)
    var inputFile: String? = null

    fun statistic() {
        val list = createdList(File(inputFile.toString()))
        if (text != "category" && text != "person") {
            throw IllegalAccessException()
        }
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val outputGenerator: JsonGenerator = factory.createGenerator(System.out)
        val printer = DefaultPrettyPrinter()
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        val listCategory = mutableListOf<String>()
        val listPerson = mutableListOf<String>()
        if (text == "category") {
            for (i in list) {
                listCategory.add(i.Category)
            }
        } else {
            for (i in list) {
                listPerson.add(i.ResponsiblePerson)
            }
        }
        if (listPerson.isEmpty() && listCategory.isEmpty()) {
            with(outputGenerator) {
                writeStartObject()
                if (text.equals("category")) {
                    writeFieldName("statisticByCategory")
                } else {
                    writeFieldName("statisticByPerson")
                }
                writeStartArray()
                writeEndArray()
            }
            outputGenerator.close()
            return
        }
        if (listPerson.isEmpty()) {
            with(outputGenerator) {
                writeStartObject()
                writeFieldName("statisticByCategory")
                writeStartArray()
                for (i in listCategory.toSet().sorted()) {
                    var count = 0
                    var price = 0.0
                    var countUsers = 0
                    val r = HashMap<String, String>()
                    for (j in list) {
                        if (j.Category == i) {
                            count++
                            price += j.Price
                            if (j.IsUsed == true) {
                                if (r.get(j.User + j.Category).equals(null)) {
                                    r.put(j.User + j.Category, "1")
                                    if (j.IsUsed == true) {
                                        countUsers++
                                    }
                                }
                            }
                        }
                    }
                    writeStartObject()
                    writeFieldName("category")
                    writeString(i)
                    writeFieldName("count")
                    writeNumber(count)
                    writeFieldName("price")
                    writeNumber(price)
                    writeFieldName("countUsers")
                    writeNumber(countUsers)
                    writeEndObject()
                }
                writeEndArray()
            }
            outputGenerator.close()
        } else {
            with(outputGenerator) {
                writeStartObject()
                writeFieldName("statisticByPerson")
                writeStartArray()
                for (i in listPerson.toSet().sorted()) {
                    var count = 0
                    var price = 0.0
                    var countUsers = 0
                    val r = HashMap<String, String>()
                    for (j in list) {
                        if (j.ResponsiblePerson == i) {
                            count++
                            price += j.Price
                            if (j.IsUsed == true) {
                                if (r.get(j.User + j.ResponsiblePerson).equals(null)) {
                                    r.put(j.User + j.ResponsiblePerson, "1")
                                    if (j.IsUsed == true) {
                                        countUsers++
                                    }
                                }
                            }
                        }
                    }
                    writeStartObject()
                    writeFieldName("Person")
                    writeString(i)
                    writeFieldName("count")
                    writeNumber(count)
                    writeFieldName("price")
                    writeNumber(price)
                    writeFieldName("countUsers")
                    writeNumber(countUsers)
                    writeEndObject()
                }
                writeEndArray()
            }
            outputGenerator.close()
        }
    }
}

@Parameters(commandNames = ["find"], separators = "=")
class FindEquipment {
    @Parameter(names = ["--location"], required = true)
    var locationSpace: String? = null

    @Parameter(names = ["--equipment-file"], description = "Input file", required = true)
    var inputFile: String? = null

    fun findEquipment() {
        val list = createdList(File(inputFile.toString()))
        if (locationSpace.equals("")) {
            exitProcess(1)
        }
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val outputGenerator: JsonGenerator = factory.createGenerator(System.out)
        val printer = DefaultPrettyPrinter()
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        val rez = mutableListOf<ItemC>()
        for (i in list) {
            if (i.Location.equals(locationSpace.toString().lowercase())) {
                rez.add(i)
            }
        }
        val outRez = rez.sortedWith(compareBy({ it.Category }, { it.Id }))
        with(outputGenerator) {
            writeStartObject()
            writeFieldName("text")
            writeString(locationSpace)
            writeFieldName("equipment")
            writeStartArray()
            for (i in outRez) {
                writeStartObject()
                writeFieldName("Id")
                writeString(i.Id.toString())
                writeFieldName("Equipment")
                writeString(i.Equipment)
                writeFieldName("Category")
                writeString(i.Category)
                writeFieldName("GuaranteeDate")
                writeString(i.GuaranteeDate.toString())
                writeFieldName("IsUsed")
                writeBoolean(i.IsUsed)
                writeFieldName("Price")
                writeNumber(i.Price)
                writeFieldName("Location")
                writeString(i.Location)
                writeFieldName("ResponsiblePerson")
                writeString(i.ResponsiblePerson)
                writeFieldName("User")
                writeString(i.User)
                writeEndObject()
            }
            writeEndArray()
        }
        outputGenerator.close()
    }
}
