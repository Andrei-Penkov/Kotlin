package ru.yarsu

import com.beust.jcommander.JCommander
import com.beust.jcommander.ParameterException
import com.github.doyaaaaaken.kotlincsv.dsl.csvReader
import com.github.doyaaaaaken.kotlincsv.dsl.csvWriter
import org.http4k.server.Netty
import org.http4k.server.asServer
import ru.yarsu.web.routes.ApplicationRoutes
import ru.yarsu.web.routes.User
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.system.exitProcess

fun createdList(file: File): List<ItemC> {
    val list = csvReader().readAll(file)
    val rez = mutableListOf<ItemC>()
    var count = 0
    for (i in list) {
        if (count == 0) {
            count++
            continue
        }
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        var o: String = "null"
        when (i[2]) {
            "монитор" -> o = ItemTypeU.Monitor.type
            "ПК" -> o = ItemTypeU.PC.type
            "телефон" -> o = ItemTypeU.Telephon.type
            "принтер" -> o = ItemTypeU.Printer.type
            "другое" -> o = ItemTypeU.Other.type
        }
        if (o.equals("null")) {
            exitProcess(1)
        }
        if (i[4].toBoolean()) {
            rez.add(
                ItemC(
                    UUID.fromString(i[0]),
                    i[1],
                    o,
                    LocalDate.parse(i[3], formatter),
                    i[4].toBoolean(),
                    i[5].toDouble(),
                    i[6],
                    i[7],
                    i[8],
                ),
            )
        } else {
            rez.add(
                ItemC(
                    UUID.fromString(i[0]),
                    i[1],
                    o,
                    LocalDate.parse(i[3], formatter),
                    i[4].toBoolean(),
                    i[5].toDouble(),
                    i[6],
                    i[7],
                ),
            )
        }
    }
    return rez
}

fun createdListUsers(file: File): List<User> {
    val list = csvReader().readAll(file)
    val rez = mutableListOf<User>()
    var count = 0
    for (i in list) {
        if (count == 0) {
            count++
            continue
        }
        rez.add(User(UUID.fromString(i[0]), i[1], i[2], i[3], i[4]))
    }
    return rez
}

fun createdListReg(file: File): List<Reg> {
    val list = csvReader().readAll(file)
    val rez = mutableListOf<Reg>()
    var count = 0
    for (i in list) {
        if (count == 0) {
            count++
            continue
        }
        rez.add(Reg(UUID.fromString(i[0]), UUID.fromString(i[1]), UUID.fromString(i[2]), i[3], i[4], i[5]))
    }
    return rez
}

fun main(args: Array<String>) {
    val argObj = Args()
    val listCommand = ListCommand()
    val showEquipment = ShowEquipment()
    val listUnusedEquipment = ListUnusedEquipment()
    val listTime = ListTime()
    val statistic = Statistic()
    val findС = FindEquipment()
    var builder = JCommander.newBuilder().addObject(argObj)
    builder.addCommand("list", listCommand)
    builder.addCommand("show-equipment", showEquipment)
    builder.addCommand("list-unused-equipment", listUnusedEquipment)
    builder.addCommand("list-time", listTime)
    builder.addCommand("statistic", statistic)
    builder.addCommand("find", findС)
    val jCommander = builder.build()
    try {
        jCommander.parse(*args)

        when (jCommander.parsedCommand) {
            "list" -> listCommand.list()
            "show-equipment" -> showEquipment.showEquipment()
            "list-unused-equipment" -> listUnusedEquipment.listUnusedEquipment()
            "list-time" -> listTime.listTime()
            "statistic" -> statistic.statistic()
            "find" -> findС.findEquipment()
            else -> {
                val file = File(argObj.inputFile)
                val reg = File(argObj.inputReg)
                val user = File(argObj.inputUser)
                val port = argObj.inputPort
                StorageItem.stor(createdList(file))
                StorageReg.stor(createdListReg(reg))
                StorageUser.stor(createdListUsers(user))
                val response = ApplicationRoutes().rez(file, reg, user)
                val jettyServer = response.asServer(Netty(port?.toInt() ?: throw IllegalArgumentException())).start()
                val printingHook =
                    thread(
                        false,
                        false,
                        null,
                        null,
                        -1,
                        {
                            val rows =
                                mutableListOf(
                                    listOf(
                                        "Id",
                                        "Equipment",
                                        "Category",
                                        "GuaranteeDate",
                                        "IsUsed",
                                        "Price",
                                        "Location",
                                        "ResponsiblePerson",
                                        "User",
                                    ),
                                )
                            for (i in StorageItem.getAll().values) {
                                rows.add(
                                    listOf(
                                        "${i.Id}",
                                        "${i.Equipment}",
                                        "${i.Category}",
                                        "${i.GuaranteeDate}",
                                        "${i.IsUsed}",
                                        "${i.Price}",
                                        "${i.Location}",
                                        "${i.ResponsiblePerson}",
                                        "${i.User}",
                                    ),
                                )
                            }
                            file.writeText("")
                            csvWriter().open(file) {
                                rows.forEach { row -> writeRow(row) }
                            }
                            val rows1 = mutableListOf(listOf("Id", "Name", "RegistrationDateTime", "Email", "Position"))
                            for (i in StorageUser.getAll().values) {
                                rows1.add(listOf("${i.Id}", "${i.Name}", "${i.RegistrationDateTime}", "${i.Email}", "${i.Position}"))
                            }
                            user.writeText("")
                            csvWriter().open(user) {
                                rows1.forEach { row -> writeRow(row) }
                            }
                            val rows2 = mutableListOf(listOf("Id", "Equipment", "ResponsiblePerson", "Operation", "Text", "LogDateTime"))
                            for (i in StorageReg.getAll().values) {
                                rows2.add(
                                    listOf(
                                        "${i.Id}",
                                        "${i.Equipment}",
                                        "${i.ResponsiblePerson}",
                                        "${i.Operation}",
                                        "${i.Text}",
                                        "${i.LogDateTime}",
                                    ),
                                )
                            }
                            reg.writeText("")
                            csvWriter().open(reg) {
                                rows2.forEach { row -> writeRow(row) }
                            }
                        },
                    )
                Runtime.getRuntime().addShutdownHook(printingHook)
            }
        }
    } catch (e: ParameterException) {
        jCommander.usage()
        println("Error ${e.message}")
        exitProcess(1)
    } catch (e: Exception) {
        jCommander.usage()
        println("Error ${e.message}")
        exitProcess(1)
    }
}
