package ru.yarsu

import java.util.UUID
import kotlin.collections.HashMap

class StorageItem {
    companion object {
        private var rez: HashMap<UUID, ItemC> = HashMap<UUID, ItemC>()

        fun stor(a: List<ItemC>): HashMap<UUID, ItemC> {
            if (rez.isEmpty()) {
                for (i in a) {
                    rez.put(i.Id, i)
                }
            }
            return rez
        }

        fun getAll(): HashMap<UUID, ItemC> = rez

        fun getTriangle(id: UUID): ItemC? = rez.get(id)

        fun putTriangle(triangle: ItemC) {
            rez.put(triangle.Id, triangle)
        }
    }
}
