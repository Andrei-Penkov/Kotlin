package ru.yarsu.web.routes

import com.fasterxml.jackson.core.JsonFactory
import com.fasterxml.jackson.core.JsonFactoryBuilder
import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.util.DefaultIndenter
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter
import org.http4k.core.ContentType
import org.http4k.core.HttpHandler
import org.http4k.core.Request
import org.http4k.core.Response
import org.http4k.core.Status
import org.http4k.lens.contentType
import org.http4k.routing.path
import org.json.JSONObject
import ru.yarsu.StorageItem
import ru.yarsu.StorageUser
import java.io.File
import java.io.StringWriter
import java.util.UUID

class DeleteUser(
    val file: File,
    val log: File,
    val user: File,
) : HttpHandler {
    override fun invoke(request: Request): Response {
        val by: String? = request.path("user-id")
        try {
            val list = StorageUser.getAll().values
            UUID.fromString(by)
            var flag = 0
            for (i in list) {
                if (i.Id.equals(UUID.fromString(UUID.fromString(by).toString()))) {
                    flag = 1
                    break
                }
            }
            val userYes =
                StorageItem
                    .getAll()
                    .values
                    .filter { it.User == by || it.ResponsiblePerson == by }
                    .sortedBy { it.Id }
            if (flag.equals(0)) {
                return Response(
                    Status.NOT_FOUND,
                ).contentType(
                    ContentType.APPLICATION_JSON,
                ).body(JSONObject().put("UserId", by).put("Error", "Работник не найден").toString())
            }
            if (userYes.isNotEmpty()) {
                val factory: JsonFactory = JsonFactoryBuilder().build()
                val s = StringWriter()
                val outputGenerator: JsonGenerator = factory.createGenerator(s)
                val printer = DefaultPrettyPrinter()
                printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
                outputGenerator.prettyPrinter = printer
                with(outputGenerator) {
                    writeStartArray()
                    for (i in userYes) {
                        writeStartObject()
                        writeFieldName("Id")
                        writeString(i.Id.toString())
                        writeFieldName("Equipment")
                        writeString(i.Equipment)
                        writeEndObject()
                    }
                    writeEndArray()
                }
                outputGenerator.close()
                return Response(Status.FORBIDDEN).contentType(ContentType.APPLICATION_JSON).body(s.toString())
            } else {
                StorageUser.deleteTriangle(UUID.fromString(by))
                return Response(Status.NO_CONTENT).contentType(ContentType.APPLICATION_JSON).body(JSONObject().put("Id", by).toString())
            }
        } catch (e: Exception) {
            return Response(Status.BAD_REQUEST).contentType(ContentType.APPLICATION_JSON).body(
                JSONObject()
                    .put(
                        "Error",
                        "Некорректный индетификатор техники. Для параметра equipment-id индетификатор техники, но получено значение «$by»",
                    ).toString(),
            )
        }
    }
}
