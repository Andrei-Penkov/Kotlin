package ru.yarsu.web.routes

import com.fasterxml.jackson.core.JsonFactory
import com.fasterxml.jackson.core.JsonFactoryBuilder
import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.util.DefaultIndenter
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter
import org.http4k.core.ContentType
import org.http4k.core.HttpHandler
import org.http4k.core.Request
import org.http4k.core.Response
import org.http4k.core.Status
import org.http4k.core.body.form
import org.http4k.lens.contentType
import org.http4k.routing.path
import org.json.JSONObject
import ru.yarsu.StorageItem
import ru.yarsu.StorageReg
import java.io.File
import java.io.StringWriter
import java.util.UUID

class PutReg(
    val file: File,
    val log: File,
    val user: File,
) : HttpHandler {
    fun g(
        by: String,
        byReg: String,
        operation: String,
        text: String,
    ) {
        val a = StorageReg.getTriangle(UUID.fromString(byReg))
        val b = a?.copy(Operation = operation, Text = text)
        b?.let { StorageReg.putTriangle(it) }
    }

    override fun invoke(request: Request): Response {
        val by: String? = request.path("equipment-id")
        val byReg: String? = request.path("log-id")
        try {
            UUID.fromString(by)
            UUID.fromString(byReg)
        } catch (ex: Exception) {
            return Response(
                Status.NOT_FOUND,
            ).contentType(
                ContentType.APPLICATION_JSON,
            ).body(
                JSONObject()
                    .put(
                        "Error",
                        "Некорректное значение переданного параметра id. Ожидается UUID, но получено текстовое значение",
                    ).toString(),
            )
        }

        var operation = ""
        request.form("Operation")?.let {
            operation = it
        }
        var text = ""
        request.form("Text")?.let {
            text = it
        }
        if (operation == "" && text == "") {
            val s = StringWriter()
            val factory: JsonFactory = JsonFactoryBuilder().build()
            val outputGenerator: JsonGenerator = factory.createGenerator(s)
            val printer = DefaultPrettyPrinter()
            printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
            with(outputGenerator) {
                writeStartObject()
                writeFieldName("Operation")
                writeStartObject()
                writeFieldName("Value")
                writeString(operation)
                writeFieldName("Error")
                writeString("Отсутствует поле")
                writeEndObject()
                writeFieldName("Text")
                writeStartObject()
                writeFieldName("Value")
                writeString(operation)
                writeFieldName("Error")
                writeString("Отсутствует поле")
                writeEndObject()
                writeEndObject()
            }
            outputGenerator.close()
            return Response(Status.BAD_REQUEST).contentType(ContentType.APPLICATION_JSON).body(s.toString())
        }
        if (operation == "") {
            val s = StringWriter()
            val factory: JsonFactory = JsonFactoryBuilder().build()
            val outputGenerator: JsonGenerator = factory.createGenerator(s)
            val printer = DefaultPrettyPrinter()
            printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
            with(outputGenerator) {
                writeStartObject()
                writeFieldName("Operation")
                writeStartObject()
                writeFieldName("Value")
                writeString(operation)
                writeFieldName("Error")
                writeString("Отсутствует поле")
                writeEndObject()
                writeEndObject()
            }
            outputGenerator.close()
            return Response(Status.BAD_REQUEST).contentType(ContentType.APPLICATION_JSON).body(s.toString())
        }
        if (text == "") {
            val s = StringWriter()
            val factory: JsonFactory = JsonFactoryBuilder().build()
            val outputGenerator: JsonGenerator = factory.createGenerator(s)
            val printer = DefaultPrettyPrinter()
            printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
            with(outputGenerator) {
                writeStartObject()
                writeFieldName("Text")
                writeStartObject()
                writeFieldName("Value")
                writeString(text)
                writeFieldName("Error")
                writeString("Отсутствует поле")
                writeEndObject()
                writeEndObject()
            }
            outputGenerator.close()
            return Response(Status.BAD_REQUEST).contentType(ContentType.APPLICATION_JSON).body(s.toString())
        }
//        if (StorageItem.getTriangle(UUID.fromString(by)) == null) {
//            return Response(Status.NOT_FOUND).contentType(ContentType.APPLICATION_JSON).body(
//                "{\n" +
//                    "\"EquipmentId\": \"${by}\",\n" +
//                    "\"LogId\": \"${byReg}\"\n" +
//                    "}",
//            )
//        }
//        if (StorageReg.getTriangle(UUID.fromString(byReg)) == null) {
//            return Response(Status.NOT_FOUND).contentType(ContentType.APPLICATION_JSON).body(
//                "{\n" +
//                    "\"EquipmentId\": \"${by}\",\n" +
//                    "\"LogId\": \"${byReg}\"\n" +
//                    "}",
//            )
//        }
//        if (StorageReg.getTriangle(UUID.fromString(byReg))!!.Equipment != UUID.fromString(by)) {
//            return Response(Status.NOT_FOUND).contentType(ContentType.APPLICATION_JSON).body(
//                "{\n" +
//                    "\"EquipmentId\": \"${by}\",\n" +
//                    "\"LogId\": \"${byReg}\"\n" +
//                    "}",
//            )
//        }
        if (!StorageItem.getAll().keys.contains(UUID.fromString(by)) && !StorageReg.getAll().keys.contains(UUID.fromString(byReg))) {
            return Response(Status.NOT_FOUND).contentType(ContentType.APPLICATION_JSON).body(
                "{\n" +
                    "\"EquipmentId\": \"${by}\",\n" +
//                    "\"LogId\": \"${byReg}\"\n" +
                    "}",
            )
        }
        if (!StorageReg.getAll().keys.contains(UUID.fromString(byReg))) {
            return Response(Status.NOT_FOUND).contentType(ContentType.APPLICATION_JSON).body(
                "{\n" +
                    "\"LogId\": \"${byReg}\"\n" +
                    "}",
            )
        }
        if (!StorageItem.getAll().keys.contains(UUID.fromString(by))) {
            return Response(Status.NOT_FOUND).contentType(ContentType.APPLICATION_JSON).body(
                "{\n" +
                    "\"EquipmentId\": \"${by}\",\n" +
                    "}",
            )
        }
        if (StorageReg.getTriangle(UUID.fromString(byReg))!!.Equipment != UUID.fromString(by)
        ) {
            return Response(Status.NOT_FOUND).contentType(ContentType.APPLICATION_JSON).body(
                "{\n" +
//                    "\"EquipmentId\": \"${by}\",\n" +
                    "\"LogId\": \"${byReg}\"\n" +
                    "}",
            )
        }
        g(by.toString(), byReg.toString(), operation, text)
        return Response(Status.NO_CONTENT)
    }
}
