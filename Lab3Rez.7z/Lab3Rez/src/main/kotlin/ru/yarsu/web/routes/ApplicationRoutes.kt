package ru.yarsu.web.routes

import org.http4k.core.ContentType
import org.http4k.core.Method
import org.http4k.core.Response
import org.http4k.core.Status
import org.http4k.lens.contentType
import org.http4k.routing.RoutingHttpHandler
import org.http4k.routing.bind
import org.http4k.routing.routes
import org.json.JSONObject
import java.io.File

class ApplicationRoutes {
    fun rez(
        file: File,
        log: File,
        user: File,
    ): RoutingHttpHandler {
        val machine =
            routes(
                "list-unused-equipment" bind Method.GET to HandlerTree(file, log, user),
                "list-time" bind Method.GET to HandlerFour(file, log, user),
                "statistic" bind Method.GET to HandlerFive(file, log, user),
            )
        val web =
            routes(
                "list-equipment" bind Method.GET to HandlerOne(file, log, user),
                "equipment/{equipment-id}" bind Method.GET to HandlerTwo(file, log, user),
                "equipment/" bind Method.GET to {
                    Response(Status.BAD_REQUEST)
                        .contentType(ContentType.APPLICATION_JSON)
                        .body(
                            JSONObject()
                                .put(
                                    "error",
                                    "Некорректное значение параметра equipment-id. Ожидается id оборудования но получено null",
                                ).toString(),
                        )
                },
                "machine" bind machine,
            )
        val web2 =
            routes(
                "equipment" bind Method.POST to PostItem(file, log, user),
                "equipment" bind Method.GET to HandlerOne(file, log, user),
                "equipment/unused" bind Method.GET to HandlerTree(file, log, user),
                "equipment/by-time" bind Method.GET to HandlerFour(file, log, user),
                "equipment/statistics" bind Method.GET to HandlerFive(file, log, user),
                "equipment/{equipment-id}" bind Method.GET to HandlerTwo(file, log, user),
                "equipment/" bind Method.GET to {
                    Response(Status.BAD_REQUEST)
                        .contentType(ContentType.APPLICATION_JSON)
                        .body(
                            JSONObject()
                                .put(
                                    "Error",
                                    "Некорректное значение параметра equipment-id. Ожидается id оборудования но получено null",
                                ).toString(),
                        )
                },
                "equipment/{equipment-id}" bind Method.PATCH to PatchItem(file, log, user),
                "equipment/" bind Method.PATCH to {
                    Response(Status.BAD_REQUEST)
                        .contentType(ContentType.APPLICATION_JSON)
                        .body(
                            JSONObject()
                                .put(
                                    "Error",
                                    "Некорректное значение параметра equipment-id. Ожидается id оборудования но получено null",
                                ).toString(),
                        )
                },
                "equipment/{equipment-id}/log/{log-id}" bind Method.PUT to PutReg(file, log, user),
                "equipment//log/" bind Method.PUT to {
                    Response(Status.BAD_REQUEST)
                        .contentType(ContentType.APPLICATION_JSON)
                        .body(
                            JSONObject()
                                .put(
                                    "Error",
                                    "Некорректное значение параметра equipment-id или log-id. Ожидается id оборудования или записи но получено null",
                                ).toString(),
                        )
                },
                "users" bind Method.POST to PostUser(file, log, user),
                "users" bind Method.GET to GetUser(file, log, user),
                "users/{user-id}" bind Method.DELETE to DeleteUser(file, log, user),
                "users/" bind Method.DELETE to {
                    Response(Status.BAD_REQUEST)
                        .contentType(ContentType.APPLICATION_JSON)
                        .body(
                            JSONObject()
                                .put(
                                    "Error",
                                    "Некорректное значение параметра equipment-id. Ожидается id оборудования но получено null",
                                ).toString(),
                        )
                },
            )
        val app =
            routes(
                "ping" bind Method.GET to { Response(Status.OK).body("pong") },
                "v1" bind web,
                "v2" bind web2,
            )
        return app
    }
}
