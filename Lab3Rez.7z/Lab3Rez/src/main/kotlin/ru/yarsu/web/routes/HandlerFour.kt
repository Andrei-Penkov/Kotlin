package ru.yarsu.web.routes

import com.fasterxml.jackson.core.JsonFactory
import com.fasterxml.jackson.core.JsonFactoryBuilder
import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter
import org.http4k.core.ContentType
import org.http4k.core.HttpHandler
import org.http4k.core.Request
import org.http4k.core.Response
import org.http4k.core.Status
import org.http4k.core.findSingle
import org.http4k.core.queries
import org.http4k.lens.contentType
import org.json.JSONObject
import ru.yarsu.ItemC
import ru.yarsu.StorageItem
import java.io.File
import java.io.StringWriter
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class HandlerFour(
    val file: File,
    val log: File,
    val user: File,
) : HttpHandler {
    fun listTime(
        size: Int,
        page: Int,
        time: String,
    ): StringWriter {
        if (time.equals(null)) {
            throw IllegalArgumentException()
        }
        val list = StorageItem.getAll().values
        val s = StringWriter()
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val outputGenerator: JsonGenerator = factory.createGenerator(s)
        outputGenerator.prettyPrinter = DefaultPrettyPrinter()
        val list1 = mutableListOf<ItemC>()
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        for (i in list) {
            LocalDateTime.parse(time)
            if (i.GuaranteeDate <= (LocalDate.parse(time.split("T")[0], formatter))) {
                list1.add(i)
            }
        }
        val list2 = list1.sortedWith(compareBy({ it.Category }, { it.Id }))
        with(outputGenerator) {
//            writeStartObject()
//            writeFieldName("time")
//            writeString(time)
//            writeFieldName("equipment")
            writeStartArray()
            for (i in list2) {
                writeStartObject()
                writeFieldName("Id")
                writeString(i.Id.toString())
                writeFieldName("Equipment")
                writeString(i.Equipment)
                writeFieldName("GuaranteeDate")
                writeString(i.GuaranteeDate.toString())
                writeEndObject()
            }
            writeEndArray()
        }
        outputGenerator.close()
        return s
    }

    override fun invoke(request: Request): Response {
        val params = request.uri.queries()
        val by = params.findSingle("time")
        var page = 1
        request.query("page")?.let {
            try {
                page = it.toInt()
                if (page < 1) throw IllegalArgumentException()
            } catch (e: Exception) {
                return Response(Status.BAD_REQUEST)
                    .contentType(ContentType.APPLICATION_JSON)
                    .body(
                        JSONObject()
                            .put(
                                "Error",
                                "Некорректное значение параметра page. Ожидается натуральное число > 0, но получено $page",
                            ).toString(),
                    )
            }
        }
        var size = 10
        val arr = arrayOf(5, 10, 20, 50)
        request.query("records-per-page")?.let {
            try {
                size = it.toInt()
                if (!arr.contains(size)) throw IllegalArgumentException()
            } catch (e: Exception) {
                return Response(Status.BAD_REQUEST)
                    .contentType(ContentType.APPLICATION_JSON)
                    .body(
                        JSONObject()
                            .put(
                                "Error",
                                "Некорректное значение параметра records-per-page. Ожидается натуральное число из множества (5,10,20,50), но получено $size",
                            ).toString(),
                    )
            }
        }
        try {
            return Response(Status.OK)
                .contentType(ContentType.APPLICATION_JSON)
                .body(listTime(size, page, by.toString()).toString())
        } catch (e: Exception) {
            return Response(Status.BAD_REQUEST).contentType(ContentType.APPLICATION_JSON).body(
                JSONObject().put("Error", "Для параметра time ожидается дата и время, но получено «$by»").toString(),
            )
        }
    }
}
