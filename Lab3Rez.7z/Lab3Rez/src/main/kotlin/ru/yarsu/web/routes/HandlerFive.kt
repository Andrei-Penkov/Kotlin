package ru.yarsu.web.routes

import com.fasterxml.jackson.core.JsonFactory
import com.fasterxml.jackson.core.JsonFactoryBuilder
import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.util.DefaultIndenter
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter
import org.http4k.core.ContentType
import org.http4k.core.HttpHandler
import org.http4k.core.Request
import org.http4k.core.Response
import org.http4k.core.Status
import org.http4k.core.findSingle
import org.http4k.core.queries
import org.http4k.lens.contentType
import org.json.JSONObject
import ru.yarsu.StorageItem
import ru.yarsu.StorageUser
import java.io.File
import java.io.StringWriter

class HandlerFive(
    val file: File,
    val log: File,
    val user: File,
) : HttpHandler {
    fun statistic(TEXT: String): StringWriter {
        val list = StorageItem.getAll().values
        val user = StorageUser.getAll().values
        if (TEXT != "category" && TEXT != "person") {
            throw IllegalAccessException()
        }
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val s = StringWriter()
        val outputGenerator: JsonGenerator = factory.createGenerator(s)
        val printer = DefaultPrettyPrinter()
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        val listCategory = mutableListOf<String>()
        val listPerson = mutableListOf<User>()
        val userName = mutableListOf<String>()
        if (TEXT == "category") {
            for (i in list) {
                listCategory.add(i.Category)
            }
        } else {
            for (i in list) {
                for (k in user) {
                    if (i.ResponsiblePerson == k.Id.toString()) {
                        listPerson.add(k)
                    }
                }
            }
        }
        if (listPerson.isEmpty() && listCategory.isEmpty()) {
            with(outputGenerator) {
                writeStartObject()
                if (TEXT.equals("category")) {
                    writeFieldName("statisticByCategory")
                } else {
                    writeFieldName("statisticByPerson")
                }
                writeStartArray()
                writeEndArray()
            }
            outputGenerator.close()
            return s
        }
        if (listPerson.isEmpty()) {
            with(outputGenerator) {
                writeStartObject()
                writeFieldName("statisticByCategory")
                writeStartArray()
                for (i in listCategory.toSet().sorted()) {
                    var count = 0
                    var price = 0.0
                    var countUsers = 0
                    val r = HashMap<String, String>()
                    for (j in list) {
                        if (j.Category == i) {
                            count++
                            price += j.Price
                            if (j.IsUsed == true) {
                                if (r.get(j.User + j.Category).equals(null)) {
                                    r.put(j.User + j.Category, "1")
                                    if (j.IsUsed == true) {
                                        countUsers++
                                    }
                                }
                            }
                        }
                    }
                    writeStartObject()
                    writeFieldName("Category")
                    writeString(i)
                    writeFieldName("Count")
                    writeNumber(count)
                    writeFieldName("Price")
                    writeNumber(price)
                    writeFieldName("CountUsers")
                    writeNumber(countUsers)
                    writeEndObject()
                }
                writeEndArray()
            }
            outputGenerator.close()
        } else {
            with(outputGenerator) {
                writeStartObject()
                writeFieldName("statisticByPerson")
                writeStartArray()
                for (i in listPerson.toSet().sortedBy { it.Name }) {
                    var count = 0
                    var price = 0.0
                    var countUsers = 0
                    val r = HashMap<String, String>()
                    for (j in list) {
                        if (j.ResponsiblePerson == i.Id.toString()) {
                            count++
                            price += j.Price
                            if (j.IsUsed == true) {
                                if (r.get(j.User + j.ResponsiblePerson).equals(null)) {
                                    r.put(j.User + j.ResponsiblePerson, "1")
                                    if (j.IsUsed == true) {
                                        countUsers++
                                    }
                                }
                            }
                        }
                    }
                    writeStartObject()
                    writeFieldName("Person")
//                    for (k in user.sortedBy { it.Name }) {
//                        if (k.Id.toString().equals(i)) {
//                            writeString(k.Name)
//                        }
//                    }
                    writeString(i.Name)
                    writeFieldName("Count")
                    writeNumber(count)
                    writeFieldName("Price")
                    writeNumber(price)
                    writeFieldName("CountUsers")
                    writeNumber(countUsers)
                    writeEndObject()
                }
                writeEndArray()
            }
            outputGenerator.close()
        }
        return s
    }

    override fun invoke(request: Request): Response {
        val params = request.uri.queries()
        val by = params.findSingle("by-type")
        try {
            return Response(Status.OK)
                .contentType(ContentType.APPLICATION_JSON)
                .body(statistic(by.toString()).toString())
        } catch (e: Exception) {
            return Response(Status.BAD_REQUEST).contentType(ContentType.APPLICATION_JSON).body(
                JSONObject()
                    .put("Error", "Для параметра by-type ожидается тип статистики, но получено «$by»")
                    .toString(),
            )
        }
    }
}
