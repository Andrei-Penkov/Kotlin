package ru.yarsu.web.routes

import com.fasterxml.jackson.core.JsonFactory
import com.fasterxml.jackson.core.JsonFactoryBuilder
import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.util.DefaultIndenter
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter
import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.JsonNodeType
import org.http4k.core.Body
import org.http4k.core.ContentType
import org.http4k.core.HttpHandler
import org.http4k.core.Request
import org.http4k.core.Response
import org.http4k.core.Status
import org.http4k.format.Jackson.auto
import org.http4k.format.Jackson.json
import org.http4k.lens.contentType
import org.http4k.routing.path
import ru.yarsu.Reg
import ru.yarsu.StorageItem
import ru.yarsu.StorageReg
import ru.yarsu.StorageUser
import java.io.File
import java.io.StringWriter
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.UUID

data class Message1(
    val Equipment: String,
    val Category: String?,
    val GuaranteeDate: LocalDate?,
    val Price: Double?,
    val Location: String,
    val ResponsiblePerson: UUID?,
    val User: UUID?,
    val Operation: String,
    val Text: String?,
)

data class MessageHelp1(
    val Equipment: Any?,
    val Category: Any?,
    val GuaranteeDate: Any?,
    val Price: Any?,
    val Location: Any?,
    val ResponsiblePerson: Any?,
    val User: Any?,
    val Operation: Any?,
    val Text: Any?,
)

class PatchItem(
    val file: File,
    val log: File,
    val user: File,
) : HttpHandler {
    fun errorResponse(m: MessageHelp1): StringWriter {
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val s = StringWriter()
        val outputGenerator: JsonGenerator = factory.createGenerator(s)
        val printer = DefaultPrettyPrinter()
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        with(outputGenerator) {
            writeStartObject()
            try {
                if (m.Equipment !is String) {
                    throw IllegalAccessException()
                }
            } catch (ex: Exception) {
                writeFieldName("Equipment")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Equipment.toString())
                writeFieldName("Error")
                writeString("Ожидается строка")
                writeEndObject()
            }
            try {
                val list = listOf("монитор", "ПК", "телефон", "принтер", "другое")
                if (m.Category != null) {
                    if (!list.contains(m.Category)) {
                        throw IllegalArgumentException()
                    }
                } else {
                    throw IllegalArgumentException()
                }
            } catch (ex: Exception) {
                writeFieldName("Category")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Category.toString())
                writeFieldName("Error")
                writeString("Ожидается корректный тип техники")
                writeEndObject()
            }
            try {
                if (m.GuaranteeDate != null) {
                    val a = LocalDate.parse(m.GuaranteeDate.toString())
                } else {
                    throw IllegalArgumentException()
                }
            } catch (ex: Exception) {
                writeFieldName("GuaranteeDate")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.GuaranteeDate.toString())
                writeFieldName("Error")
                writeString("Ожидается дата")
                writeEndObject()
            }
            try {
                if (m.Price is String) {
                    throw IllegalArgumentException()
                }
                if (m.Price == null) {
                    throw IllegalArgumentException()
                }
                if (m.Price !is Number) {
                    throw IllegalArgumentException()
                }
                if (m.Price.toDouble() < 0) {
                    throw IllegalArgumentException()
                }
            } catch (ex: Exception) {
                writeFieldName("Price")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Price.toString())
                writeFieldName("Error")
                writeString("Ожидается положительное целое число, но получен ${m.Price}")
                writeEndObject()
            }
            try {
                if (m.Location !is String) {
                    throw IllegalAccessException()
                }
            } catch (ex: Exception) {
                writeFieldName("Location")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Location.toString())
                writeFieldName("Error")
                writeString("Отсутствует поле. Ожидается строка")
                writeEndObject()
            }
            try {
                if (m.ResponsiblePerson !is String) {
                    throw IllegalAccessException()
                }
                UUID.fromString(m.ResponsiblePerson)
                if (StorageUser.getTriangle(UUID.fromString(m.ResponsiblePerson)) == null) {
                    throw IllegalAccessException()
                }
            } catch (ex: Exception) {
                writeFieldName("ResponsiblePerson")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.ResponsiblePerson.toString())
                writeFieldName("Error")
                writeString("Ожидается корректный UUID")
                writeEndObject()
            }
            try {
                var a: UUID
                if (m.User != null) {
                    if (m.User !is String) {
                        throw IllegalArgumentException()
                    }
                    if (StorageUser.getTriangle(UUID.fromString(m.User)) == null) {
                        throw IllegalAccessException()
                    }
                    a = UUID.fromString(m.User.toString())
                }
            } catch (ex: Exception) {
                writeFieldName("User")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.User.toString())
                writeFieldName("Error")
                writeString("Ожидается корректный UUID или null")
                writeEndObject()
            }
            try {
                if (m.Operation !is String) {
                    throw IllegalAccessException()
                }
                if (m.Operation == "") {
                    throw IllegalAccessException()
                }
            } catch (ex: Exception) {
                writeFieldName("Operation")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Operation.toString())
                writeFieldName("Error")
                writeString("Ожидается непустая строка")
                writeEndObject()
            }
            try {
                if (m.Text.toString() == "null") {
                    throw IllegalAccessException()
                }
                if (m.Text != null) {
                    if (m.Text !is String) {
                        throw IllegalAccessException()
                    }
                }
            } catch (ex: Exception) {
                writeFieldName("Text")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Text.toString())
                writeFieldName("Error")
                writeString("Ожидается строка")
                writeEndObject()
            }
            writeEndObject()
        }
        outputGenerator.close()
        if (s.toString().length == 3) {
            return StringWriter()
        }
        return s
    }

    fun errorResponse1(m: JsonNode): StringWriter {
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val s = StringWriter()
        val outputGenerator: JsonGenerator = factory.createGenerator(s)
        val printer = DefaultPrettyPrinter()
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        with(outputGenerator) {
            writeStartObject()
            try {
                if (m["Equipment"].isEmpty) {
                    throw IllegalAccessException()
                }
                if (m["Equipment"] == null) {
                    throw IllegalAccessException()
                }
                if (m["Equipment"].nodeType != JsonNodeType.STRING) {
                    throw IllegalAccessException()
                }
            } catch (ex: Exception) {
                writeFieldName("Equipment")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["Equipment"])
                writeFieldName("Error")
                writeString("Ожидается строка")
                writeEndObject()
            }
            try {
                if (m["Category"] != null) {
                    val list = listOf("монитор", "ПК", "телефон", "принтер", "другое")
                    if (!list.contains(m["Category"].asText())) {
                        throw IllegalArgumentException()
                    }
                }
            } catch (ex: Exception) {
                writeFieldName("Category")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["Category"])
                writeFieldName("Error")
                writeString("Ожидается корректный тип техники")
                writeEndObject()
            }
            try {
                if (m["GuaranteeDate"] != null) {
                    LocalDate.parse(m["GuaranteeDate"].asText())
                }
            } catch (ex: Exception) {
                writeFieldName("GuaranteeDate")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["GuaranteeDate"])
                writeFieldName("Error")
                writeString("Ожидается дата")
                writeEndObject()
            }
            try {
                if (m["Price"] != null) {
                    if (m["Price"].nodeType != JsonNodeType.NUMBER) {
                        throw IllegalArgumentException()
                    }
                    if (m["Price"].toString().toDouble() < 0) {
                        throw IllegalArgumentException()
                    }
                }
            } catch (ex: Exception) {
                writeFieldName("Price")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["Price"])
                writeFieldName("Error")
                writeString("Ожидается положительное целое число, но получен ${m["Price"]}")
                writeEndObject()
            }
            try {
                if (m["Location"] != null) {
                    if (m["Location"].nodeType != JsonNodeType.STRING) {
                        throw IllegalAccessException()
                    }
                }
            } catch (ex: Exception) {
                writeFieldName("Location")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["Location"])
                writeFieldName("Error")
                writeString("Отсутствует поле. Ожидается строка")
                writeEndObject()
            }
            try {
                if (m["ResponsiblePerson"] != null) {
                    if (m["ResponsiblePerson"].nodeType != JsonNodeType.STRING) {
                        throw IllegalAccessException()
                    }
                    UUID.fromString(m["ResponsiblePerson"].asText())
                }
            } catch (ex: Exception) {
                writeFieldName("ResponsiblePerson")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["ResponsiblePerson"])
                writeFieldName("Error")
                writeString("Ожидается корректный UUID")
                writeEndObject()
            }
            try {
                if (m["User"] != null) {
                    if (m["User"].nodeType != JsonNodeType.STRING) {
                        throw IllegalAccessException()
                    }
                }
            } catch (ex: Exception) {
                writeFieldName("User")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["User"])
                writeFieldName("Error")
                writeString("Ожидается корректный UUID или null")
                writeEndObject()
            }
            try {
                if (m["Operation"] == null) {
                    throw IllegalAccessException()
                }
                if (m["Operation"].nodeType != JsonNodeType.STRING) {
                    throw IllegalAccessException()
                }
                if (m["Operation"].toString() == "") {
                    throw IllegalAccessException()
                }
            } catch (ex: Exception) {
                writeFieldName("Operation")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["Operation"])
                writeFieldName("Error")
                writeString("Ожидается непустая строка")
                writeEndObject()
            }
            try {
                if (m["Text"] != null) {
                    if (m["Text"].nodeType != JsonNodeType.STRING) {
                        throw IllegalAccessException()
                    }
                }
            } catch (ex: Exception) {
                writeFieldName("Text")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["Text"])
                writeFieldName("Error")
                writeString("Ожидается строка")
                writeEndObject()
            }
            writeEndObject()
        }
        outputGenerator.close()
        if (s.toString().length == 3) {
            return StringWriter()
        }
        return s
    }

    override fun invoke(request: Request): Response {
        val messageLens = Body.auto<Message1>().toLens()
        val jsonlens = Body.json().toLens()
        val messagehelpLens = Body.auto<MessageHelp1>().toLens()
        val by: String? = request.path("equipment-id")
        try {
            UUID.fromString(by)
        } catch (ex: Exception) {
            return Response(Status.BAD_REQUEST).contentType(ContentType.APPLICATION_JSON).body(
                "{\n" +
                    "\"Error\": \"Некорректное значение переданного параметра id. Ожидается UUID, но получено текстовое значение\"\n" +
                    "}",
            )
        }
        try {
            if (StorageItem.getTriangle(UUID.fromString(by)) == null) {
                return Response(Status.NOT_FOUND).contentType(ContentType.APPLICATION_JSON).body(
                    "{\n" +
                        "\"EquipmentId\": \"${by}\",\n" +
                        "\"Error\": \"Элемент техники не найден\"\n" +
                        "}",
                )
            }
            val messagehelp: MessageHelp1 = messagehelpLens(request)
//            val a = errorResponse1(jsonlens(request))
            val a = errorResponse(messagehelp)
            var message: Message1
            if (a.toString() == "") {
                message = messageLens(request)
                var isUsed: Boolean
                if (message.User != null) {
                    isUsed = true
                } else {
                    isUsed = false
                }
                var idReg = UUID.randomUUID()
                while (StorageReg.getAll().keys.contains(idReg)) {
                    idReg = UUID.randomUUID()
                }
                val dataNew = LocalDateTime.now()
                val un = StorageItem.getTriangle(UUID.fromString(by))
                var item = un?.copy(Equipment = message.Equipment, Location = message.Location)
                if (message.Category != null) {
                    item = message.Category?.let { item?.copy(Category = it) }
                }
                if (message.GuaranteeDate != null) {
                    item = message.GuaranteeDate?.let { item?.copy(GuaranteeDate = it) }
                }
                if (message.Price != null) {
                    item = message.Price?.let { item?.copy(Price = it) }
                }
                if (message.ResponsiblePerson != null) {
                    item = message.ResponsiblePerson?.let { item?.copy(ResponsiblePerson = it.toString()) }
                }
                if (message.User != null) {
                    item = message.User?.let { item?.copy(User = it.toString()) }
                } else {
                    item = item?.copy(User = null)
                }
                item = item?.copy(IsUsed = isUsed)
                if ((item != null && item != un)) {
                    StorageItem.putTriangle(item)
                    StorageReg.putTriangle(
                        Reg(
                            idReg,
                            UUID.fromString(by),
                            UUID.fromString(item.ResponsiblePerson),
                            message.Operation,
                            message.Text.toString(),
                            dataNew.toString(),
                        ),
                    )
                    return Response(Status.CREATED).contentType(ContentType.APPLICATION_JSON).body(
                        "{\n" +
                            "\"LogId\": \"${idReg}\"\n" +
                            "}",
                    )
                }
                return Response(Status.NO_CONTENT)
            } else {
                return Response(Status.BAD_REQUEST).contentType(ContentType.APPLICATION_JSON).body(a.toString())
            }
        } catch (ex: Exception) {
            return Response(Status.BAD_REQUEST).contentType(ContentType.APPLICATION_JSON).body(
                "{\n" +
                    "\"Value\": \"{\",\n" +
                    "\"Error\": \"Missing a name for object member.\"\n" +
                    "}",
            )
        }
    }
}
