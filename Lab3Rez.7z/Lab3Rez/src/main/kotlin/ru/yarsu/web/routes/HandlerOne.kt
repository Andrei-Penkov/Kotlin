package ru.yarsu.web.routes

import com.fasterxml.jackson.core.JsonFactory
import com.fasterxml.jackson.core.JsonFactoryBuilder
import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.util.DefaultIndenter
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter
import org.http4k.core.ContentType
import org.http4k.core.HttpHandler
import org.http4k.core.Request
import org.http4k.core.Response
import org.http4k.core.Status
import org.http4k.lens.contentType
import org.json.JSONObject
import ru.yarsu.StorageItem
import java.io.File
import java.io.StringWriter
import kotlin.math.min

class HandlerOne(
    val file: File,
    val log: File,
    val user: File,
) : HttpHandler {
    fun list(
        size: Int,
        page: Int,
    ): StringWriter {
        val list = StorageItem.getAll().values
        var outputList = list.sortedWith(compareBy({ it.Category }, { it.Id }))
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val s = StringWriter()
        val outputGenerator: JsonGenerator = factory.createGenerator(s)
        val printer = DefaultPrettyPrinter()
        for (i in 1..<page) outputList = outputList.drop(min(size, outputList.size))
        outputList = outputList.take(size)
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        with(outputGenerator) {
            if (outputList.isEmpty()) {
                writeStartArray()
                writeEndArray()
                outputGenerator.close()
                return s
            }
            writeStartArray()
            for (i in outputList) {
                writeStartObject()
                writeFieldName("Id")
                writeString(i.Id.toString())
                writeFieldName("Equipment")
                writeString(i.Equipment)
                writeFieldName("IsUsed")
                writeBoolean(i.IsUsed)
                writeEndObject()
            }
            writeEndArray()
        }
        outputGenerator.close()
        return s
    }

    override fun invoke(request: Request): Response {
        var page = 1
        request.query("page")?.let {
            try {
                page = it.toInt()
                if (page < 1) throw IllegalArgumentException()
            } catch (e: Exception) {
                return Response(Status.BAD_REQUEST)
                    .contentType(ContentType.APPLICATION_JSON)
                    .body(
                        JSONObject()
                            .put(
                                "Error",
                                "Некорректное значение параметра page. Ожидается натуральное число > 0, но получено $page",
                            ).toString(),
                    )
            }
        }
        var size = 10
        val arr = arrayOf(5, 10, 20, 50)
        request.query("records-per-page")?.let {
            try {
                size = it.toInt()
                if (!arr.contains(size)) throw IllegalArgumentException()
            } catch (e: Exception) {
                return Response(Status.BAD_REQUEST)
                    .contentType(ContentType.APPLICATION_JSON)
                    .body(
                        JSONObject()
                            .put(
                                "Error",
                                "Некорректное значение параметра records-per-page. Ожидается натуральное число из множества (5,10,20,50), но получено $size",
                            ).toString(),
                    )
            }
        }
        return Response(Status.OK).contentType(ContentType.APPLICATION_JSON).body(list(size, page).toString())
    }
}
