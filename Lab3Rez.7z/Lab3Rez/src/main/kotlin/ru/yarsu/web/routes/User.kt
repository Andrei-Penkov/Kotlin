package ru.yarsu.web.routes

import java.util.UUID

data class User(
    val Id: UUID,
    val Name: String,
    val RegistrationDateTime: String,
    val Email: String,
    val Position: String,
)
