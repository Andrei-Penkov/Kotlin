package ru.yarsu.web.routes

import com.fasterxml.jackson.core.JsonFactory
import com.fasterxml.jackson.core.JsonFactoryBuilder
import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter
import org.http4k.core.ContentType
import org.http4k.core.HttpHandler
import org.http4k.core.Request
import org.http4k.core.Response
import org.http4k.core.Status
import org.http4k.core.findSingle
import org.http4k.core.queries
import org.http4k.lens.contentType
import org.json.JSONObject
import ru.yarsu.ItemC
import ru.yarsu.StorageItem
import java.io.File
import java.io.StringWriter
import kotlin.math.min

class HandlerTree(
    val file: File,
    val log: File,
    val user: File,
) : HttpHandler {
    fun listUnusedEquipment(
        size: Int,
        page: Int,
        TEXT: String,
    ): StringWriter {
        val list = StorageItem.getAll().values
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val s = StringWriter()
        if (TEXT != "null" && TEXT != "") {
            for (i in TEXT.split(",")) {
                when (i) {
                    "монитор" -> continue
                    "ПК" -> continue
                    "телефон" -> continue
                    "принтер" -> continue
                    "другое" -> continue
                    else -> {
                        throw IllegalAccessException()
                    }
                }
            }
        }
        val outputGenerator: JsonGenerator = factory.createGenerator(s)
        outputGenerator.prettyPrinter = DefaultPrettyPrinter()
        val rez = list.sortedWith(compareBy({ it.Category }, { it.Id }))
        val categores = TEXT.split(",")
        with(outputGenerator) {
            var list1 = mutableListOf<ItemC>()
            if (TEXT != "null" && TEXT != "") {
                list1 = rez.filter { it.Category in categores }.toMutableList()
                list1 = list1.filter { !it.IsUsed }.toMutableList()
            } else {
                list1 = rez.filter { !it.IsUsed }.toMutableList()
            }
            if (list1.isEmpty()) {
                writeStartArray()
                writeEndArray()
                outputGenerator.close()
                return s
            }
            writeStartArray()
            var outputList = list1.sortedWith(compareBy({ it.Category }, { it.Id }))
            for (i in 1..<page) outputList = outputList.drop(min(size, outputList.size))
            outputList = outputList.take(size)
            for (i in outputList) {
                writeStartObject()
                writeFieldName("Id")
                writeString(i.Id.toString())
                writeFieldName("Equipment")
                writeString(i.Equipment)
                writeEndObject()
            }
            writeEndArray()
        }
        outputGenerator.close()
        return s
    }

    override fun invoke(request: Request): Response {
        val params = request.uri.queries()
        val by = params.findSingle("category")
        var page = 1
        request.query("page")?.let {
            try {
                page = it.toInt()
                if (page < 1) throw IllegalArgumentException()
            } catch (e: Exception) {
                return Response(Status.BAD_REQUEST)
                    .contentType(ContentType.APPLICATION_JSON)
                    .body(
                        JSONObject()
                            .put(
                                "Error",
                                "Некорректное значение параметра page. Ожидается натуральное число > 0, но получено $page",
                            ).toString(),
                    )
            }
        }
        var size = 10
        val arr = arrayOf(5, 10, 20, 50)
        request.query("records-per-page")?.let {
            try {
                size = it.toInt()
                if (!arr.contains(size)) throw IllegalArgumentException()
            } catch (e: Exception) {
                return Response(Status.BAD_REQUEST)
                    .contentType(ContentType.APPLICATION_JSON)
                    .body(
                        JSONObject()
                            .put(
                                "Error",
                                "Некорректное значение параметра records-per-page. Ожидается натуральное число из множества (5,10,20,50), но получено $size",
                            ).toString(),
                    )
            }
        }
        try {
            return Response(Status.OK)
                .contentType(ContentType.APPLICATION_JSON)
                .body(listUnusedEquipment(size, page, by.toString()).toString())
        } catch (e: Exception) {
            return Response(Status.BAD_REQUEST).contentType(ContentType.APPLICATION_JSON).body(
                JSONObject()
                    .put(
                        "Error",
                        "Некорректная категория. Для параметра category ожидается тип техники, но получено «$by»",
                    ).toString(),
            )
        }
    }
}
