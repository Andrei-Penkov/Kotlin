package ru.yarsu.web.routes

import com.fasterxml.jackson.core.JsonFactory
import com.fasterxml.jackson.core.JsonFactoryBuilder
import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.util.DefaultIndenter
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter
import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.JsonNodeType
import org.http4k.core.Body
import org.http4k.core.ContentType
import org.http4k.core.HttpHandler
import org.http4k.core.Request
import org.http4k.core.Response
import org.http4k.core.Status
import org.http4k.format.Jackson.auto
import org.http4k.format.Jackson.json
import org.http4k.lens.contentType
import ru.yarsu.ItemC
import ru.yarsu.Reg
import ru.yarsu.StorageItem
import ru.yarsu.StorageReg
import ru.yarsu.StorageUser
import java.io.File
import java.io.StringWriter
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.UUID

data class Message(
    val Equipment: String,
    val Category: String,
    val GuaranteeDate: LocalDate,
    val Price: Double,
    val Location: String,
    val ResponsiblePerson: UUID,
    val User: UUID?,
    val Operation: String,
    val Text: String = "",
)

data class MessageHelp(
    val Equipment: Any?,
    val Category: Any?,
    val GuaranteeDate: Any?,
    val Price: Any?,
    val Location: Any?,
    val ResponsiblePerson: Any?,
    val User: Any?,
    val Operation: Any?,
    val Text: Any? = "",
)

class PostItem(
    val file: File,
    val log: File,
    val user: File,
) : HttpHandler {
    fun errorResponse(m: MessageHelp): StringWriter {
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val s = StringWriter()
        val outputGenerator: JsonGenerator = factory.createGenerator(s)
        val printer = DefaultPrettyPrinter()
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        with(outputGenerator) {
            writeStartObject()
            try {
                if (m.Equipment !is String) {
                    throw IllegalAccessException()
                }
            } catch (ex: Exception) {
                writeFieldName("Equipment")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Equipment.toString())
                writeFieldName("Error")
                writeString("Ожидается строка")
                writeEndObject()
            }
            try {
                val list = listOf("монитор", "ПК", "телефон", "принтер", "другое")
                if (!list.contains(m.Category)) {
                    throw IllegalArgumentException()
                }
            } catch (ex: Exception) {
                writeFieldName("Category")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Category.toString())
                writeFieldName("Error")
                writeString("Ожидается корректный тип техники")
                writeEndObject()
            }
            try {
                val a = LocalDate.parse(m.GuaranteeDate.toString())
            } catch (ex: Exception) {
                writeFieldName("GuaranteeDate")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Category.toString())
                writeFieldName("Error")
                writeString("Ожидается дата")
                writeEndObject()
            }
            try {
                if (m.Price is String) {
                    throw IllegalArgumentException()
                }
                if (m.Price == null) {
                    throw IllegalArgumentException()
                }
                if (m.Price !is Number) {
                    throw IllegalArgumentException()
                }
                if (m.Price.toDouble() < 0) {
                    throw IllegalArgumentException()
                }
            } catch (ex: Exception) {
                writeFieldName("Price")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Price.toString())
                writeFieldName("Error")
                writeString("Ожидается положительное целое число, но получен ${m.Price}")
                writeEndObject()
            }
            try {
                if (m.Location !is String) {
                    throw IllegalAccessException()
                }
            } catch (ex: Exception) {
                writeFieldName("Location")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Location.toString())
                writeFieldName("Error")
                writeString("Отсутствует поле. Ожидается строка")
                writeEndObject()
            }
            try {
                if (m.ResponsiblePerson !is String) {
                    throw IllegalAccessException()
                }
                UUID.fromString(m.ResponsiblePerson)
                if (StorageUser.getTriangle(UUID.fromString(m.ResponsiblePerson)) == null) {
                    throw IllegalAccessException()
                }
            } catch (ex: Exception) {
                writeFieldName("ResponsiblePerson")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.ResponsiblePerson.toString())
                writeFieldName("Error")
                writeString("Ожидается корректный UUID")
                writeEndObject()
            }
            try {
                var a: UUID
                if (m.User != null) {
                    if (m.User !is String) {
                        throw IllegalArgumentException()
                    }
                    if (StorageUser.getTriangle(UUID.fromString(m.User)) == null) {
                        throw IllegalAccessException()
                    }
                    a = UUID.fromString(m.User.toString())
                }
            } catch (ex: Exception) {
                writeFieldName("User")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.User.toString())
                writeFieldName("Error")
                writeString("Ожидается корректный UUID или null")
                writeEndObject()
            }
            try {
                if (m.Operation !is String) {
                    throw IllegalAccessException()
                }
                if (m.Operation == "") {
                    throw IllegalAccessException()
                }
            } catch (ex: Exception) {
                writeFieldName("Operation")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Operation.toString())
                writeFieldName("Error")
                writeString("Ожидается непустая строка")
                writeEndObject()
            }
            try {
                if (m.Text.toString() == "null") {
                    throw IllegalAccessException()
                }
                if (m.Text != null) {
                    if (m.Text !is String) {
                        throw IllegalAccessException()
                    }
                }
            } catch (ex: Exception) {
                writeFieldName("Text")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Text.toString())
                writeFieldName("Error")
                writeString("Ожидается строка")
                writeEndObject()
            }
            writeEndObject()
        }
        outputGenerator.close()
        if (s.toString().length == 3) {
            return StringWriter()
        }
        return s
    }

    fun errorResponse1(m: JsonNode): StringWriter {
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val s = StringWriter()
        val outputGenerator: JsonGenerator = factory.createGenerator(s)
        val printer = DefaultPrettyPrinter()
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        with(outputGenerator) {
            writeStartObject()
            try {
                if (m["Equipment"] == null) {
                    throw IllegalAccessException()
                }
                if (m["Equipment"].nodeType != JsonNodeType.STRING) {
                    throw IllegalAccessException()
                }
            } catch (ex: Exception) {
                writeFieldName("Equipment")
                writeStartObject()
                writeFieldName("Value")
                if (m["Equipment"] == null) {
                    writeString("null")
                } else {
                    writeObject(m["Equipment"])
                }
                writeFieldName("Error")
                writeString("Ожидается строка")
                writeEndObject()
            }
            try {
                if (m["Category"] == null) {
                    throw IllegalAccessException()
                }
                val list = listOf("монитор", "ПК", "телефон", "принтер", "другое")
                if (!list.contains(m["Category"].asText())) {
                    throw IllegalArgumentException()
                }
            } catch (ex: Exception) {
                writeFieldName("Category")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["Category"])
                writeFieldName("Error")
                writeString("Ожидается корректный тип техники")
                writeEndObject()
            }
            try {
                if (m["GuaranteeDate"] == null) {
                    throw IllegalAccessException()
                }
                LocalDate.parse(m["GuaranteeDate"].asText())
            } catch (ex: Exception) {
                writeFieldName("GuaranteeDate")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["GuaranteeDate"])
                writeFieldName("Error")
                writeString("Ожидается дата")
                writeEndObject()
            }
            try {
                if (m["Price"] == null) {
                    throw IllegalArgumentException()
                }
                if (m["Price"].nodeType != JsonNodeType.NUMBER) {
                    throw IllegalArgumentException()
                }
                if (m["Price"].toString().toDouble() < 0) {
                    throw IllegalArgumentException()
                }
            } catch (ex: Exception) {
                writeFieldName("Price")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["Price"])
                writeFieldName("Error")
                writeString("Ожидается положительное целое число, но получен ${m["Price"]}")
                writeEndObject()
            }
            try {
                if (m["Location"] == null) {
                    throw IllegalAccessException()
                }
                if (m["Location"].nodeType != JsonNodeType.STRING) {
                    throw IllegalAccessException()
                }
            } catch (ex: Exception) {
                writeFieldName("Location")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["Location"])
                writeFieldName("Error")
                writeString("Отсутствует поле. Ожидается строка")
                writeEndObject()
            }
            try {
                if (m["ResponsiblePerson"] == null) {
                    throw IllegalAccessException()
                }
                if (m["ResponsiblePerson"].nodeType != JsonNodeType.STRING) {
                    throw IllegalAccessException()
                }
                UUID.fromString(m["ResponsiblePerson"].asText())
            } catch (ex: Exception) {
                writeFieldName("ResponsiblePerson")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["ResponsiblePerson"])
                writeFieldName("Error")
                writeString("Ожидается корректный UUID")
                writeEndObject()
            }
            try {
                if (m["User"] != null) {
                    if (m["User"].nodeType != JsonNodeType.STRING) {
                        throw IllegalAccessException()
                    }
                }
            } catch (ex: Exception) {
                writeFieldName("User")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["User"])
                writeFieldName("Error")
                writeString("Ожидается корректный UUID или null")
                writeEndObject()
            }
            try {
                if (m["Operation"] == null) {
                    throw IllegalAccessException()
                }
                if (m["Operation"].nodeType != JsonNodeType.STRING) {
                    throw IllegalAccessException()
                }
                if (m["Operation"].toString() == "") {
                    throw IllegalAccessException()
                }
            } catch (ex: Exception) {
                writeFieldName("Operation")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["Operation"])
                writeFieldName("Error")
                writeString("Ожидается непустая строка")
                writeEndObject()
            }
            try {
                if (m["Text"] != null) {
                    if (m["Text"].nodeType != JsonNodeType.STRING) {
                        throw IllegalAccessException()
                    }
                }
            } catch (ex: Exception) {
                writeFieldName("Text")
                writeStartObject()
                writeFieldName("Value")
                writeObject(m["Text"])
                writeFieldName("Error")
                writeString("Ожидается строка")
                writeEndObject()
            }
            writeEndObject()
        }
        outputGenerator.close()
        if (s.toString().length == 3) {
            return StringWriter()
        }
        return s
    }

    override fun invoke(request: Request): Response {
        val messageLens = Body.auto<Message>().toLens()
        val jsonlens = Body.json().toLens()

//        errorResponse1()
//        val tmp = jsonlens.invoke(request)
//        tmp["Title"].nodeType
        val messagehelpLens = Body.auto<MessageHelp>().toLens()

        try {
            val messagehelp: MessageHelp = messagehelpLens(request)
//            val a = errorResponse1(jsonlens(request))
            val a = errorResponse(messagehelp)
            var message: Message
            if (a.toString() == "") {
                message = messageLens(request)
                var id = UUID.randomUUID()
                while (StorageItem.getAll().keys.contains(id)) {
                    id = UUID.randomUUID()
                }
                var isUsed: Boolean
                if (message.User != null) {
                    isUsed = true
                } else {
                    isUsed = false
                }
                var idReg = UUID.randomUUID()
                while (StorageReg.getAll().keys.contains(idReg)) {
                    idReg = UUID.randomUUID()
                }
                val dataNew = LocalDateTime.now()
                StorageItem.putTriangle(
                    ItemC(
                        id,
                        message.Equipment,
                        message.Category,
                        message.GuaranteeDate,
                        isUsed,
                        message.Price,
                        message.Location,
                        message.ResponsiblePerson.toString(),
                        message.User.toString(),
                    ),
                )
                StorageReg.putTriangle(
                    Reg(
                        idReg,
                        id,
                        message.ResponsiblePerson,
                        message.Operation,
                        message.Text,
                        dataNew.toString(),
                    ),
                )
                return Response(Status.CREATED).contentType(ContentType.APPLICATION_JSON).body(
                    "{\n" +
                        "\"EquipmentId\": \"${id}\",\n" +
                        "\"LogId\": \"${idReg}\"\n" +
                        "}",
                )
            } else {
                return Response(Status.BAD_REQUEST).contentType(ContentType.APPLICATION_JSON).body(a.toString())
            }
        } catch (ex: Exception) {
            return Response(Status.BAD_REQUEST).contentType(ContentType.APPLICATION_JSON).body(
                "{\n" +
                    "\"Value\": \"${ex.message}\",\n" +
                    "\"Error\": \"Missing a name for object member.\"\n" +
                    "}",
            )
        }
    }
}
