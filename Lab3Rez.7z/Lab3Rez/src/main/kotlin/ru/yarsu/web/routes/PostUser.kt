package ru.yarsu.web.routes

import com.fasterxml.jackson.core.JsonFactory
import com.fasterxml.jackson.core.JsonFactoryBuilder
import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.util.DefaultIndenter
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter
import org.http4k.core.Body
import org.http4k.core.ContentType
import org.http4k.core.HttpHandler
import org.http4k.core.Request
import org.http4k.core.Response
import org.http4k.core.Status
import org.http4k.format.Jackson.auto
import org.http4k.lens.contentType
import ru.yarsu.StorageUser
import java.io.File
import java.io.StringWriter
import java.time.LocalDateTime
import java.util.UUID

data class MessageHelp2(
    val Name: Any?,
    val Email: Any?,
    val Position: Any?,
)

class PostUser(
    val file: File,
    val log: File,
    val user: File,
) : HttpHandler {
    fun errorResponse(m: MessageHelp2): StringWriter {
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val s = StringWriter()
        val outputGenerator: JsonGenerator = factory.createGenerator(s)
        val printer = DefaultPrettyPrinter()
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        with(outputGenerator) {
            writeStartObject()
            try {
                if (m.Name!is String) {
                    throw IllegalAccessException()
                }
            } catch (ex: IllegalAccessException) {
                writeFieldName("Name")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Name.toString())
                writeFieldName("Error")
                writeString("Ожидается строка")
                writeEndObject()
            }
            try {
                if (m.Email!is String) {
                    throw IllegalAccessException()
                }
            } catch (ex: IllegalAccessException) {
                writeFieldName("Email")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Email.toString())
                writeFieldName("Error")
                writeString("Ожидается строка")
                writeEndObject()
            }
            try {
                if (m.Position!is String) {
                    throw IllegalAccessException()
                }
            } catch (ex: IllegalAccessException) {
                writeFieldName("Position")
                writeStartObject()
                writeFieldName("Value")
                writeString(m.Position.toString())
                writeFieldName("Error")
                writeString("Ожидается строка")
                writeEndObject()
            }
            writeEndObject()
        }
        outputGenerator.close()
        if (s.toString().length == 3) {
            return StringWriter()
        }
        return s
    }

    override fun invoke(request: Request): Response {
        val messagehelpLens = Body.auto<MessageHelp2>().toLens()
        try {
            val messagehelp: MessageHelp2 = messagehelpLens(request)
            val a = errorResponse(messagehelp)
            if (a.toString() == "") {
                var id = UUID.randomUUID()
                while (StorageUser.getAll().keys.contains(id)) {
                    id = UUID.randomUUID()
                }
                val dataNew = LocalDateTime.now()
                if (messagehelp.Name != null || messagehelp.Email != null || messagehelp.Position != null) {
                    StorageUser.putTriangle(
                        User(
                            id,
                            messagehelp.Name.toString(),
                            dataNew.toString(),
                            messagehelp.Email.toString(),
                            messagehelp.Position.toString(),
                        ),
                    )
                }
                return Response(Status.CREATED).contentType(ContentType.APPLICATION_JSON).body(
                    "{\n" +
                        "\"Id\": \"${id}\",\n" +
                        "}",
                )
            } else {
                return Response(Status.BAD_REQUEST).contentType(ContentType.APPLICATION_JSON).body(a.toString())
            }
        } catch (ex: Exception) {
            return Response(Status.BAD_REQUEST).contentType(ContentType.APPLICATION_JSON).body(
                "{\n" +
                    "\"Value\": \"${ex.message}\",\n" +
                    "\"Error\": \"Missing a name for object member.\"\n" +
                    "}",
            )
        }
    }
}
