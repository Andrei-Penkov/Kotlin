package ru.yarsu.web.routes

import com.fasterxml.jackson.core.JsonFactory
import com.fasterxml.jackson.core.JsonFactoryBuilder
import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.util.DefaultIndenter
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter
import org.http4k.core.ContentType
import org.http4k.core.HttpHandler
import org.http4k.core.Request
import org.http4k.core.Response
import org.http4k.core.Status
import org.http4k.lens.contentType
import org.http4k.routing.path
import org.json.JSONObject
import ru.yarsu.Reg
import ru.yarsu.StorageItem
import ru.yarsu.StorageReg
import ru.yarsu.StorageUser
import java.io.File
import java.io.StringWriter
import java.util.UUID

class HandlerTwo(
    val file: File,
    val log: File,
    val user: File,
) : HttpHandler {
    fun showEquipment(equipment_id: UUID): StringWriter {
        val list = StorageItem.getAll().values
        val user = StorageUser.getAll().values
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val s = StringWriter()
        var outName: String? = null
        val outputGenerator: JsonGenerator = factory.createGenerator(s)
        val printer = DefaultPrettyPrinter()
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        with(outputGenerator) {
            for (i in list) {
                if (i.Id.equals(UUID.fromString(equipment_id.toString()))) {
                    writeStartObject()
                    writeFieldName("Id")
                    writeString(i.Id.toString())
                    writeFieldName("Equipment")
                    writeString(i.Equipment)
                    writeFieldName("Category")
                    writeString(i.Category)
                    writeFieldName("GuaranteeDate")
                    writeString(i.GuaranteeDate.toString())
                    writeFieldName("IsUsed")
                    writeBoolean(i.IsUsed)
                    writeFieldName("Price")
                    writeNumber(i.Price)
                    writeFieldName("Location")
                    writeString(i.Location)
                    writeFieldName("ResponsiblePerson")
                    writeString(i.ResponsiblePerson)
                    writeFieldName("ResponsiblePersonName")
                    for (k in user) {
                        if (i.ResponsiblePerson.equals(k.Id.toString())) {
                            writeString(k.Name)
                        }
                    }
                    writeFieldName("User")
                    if (i.User == "null") {
                        writeNull()
                    } else {
                        writeString(i.User)
                    }
                    writeFieldName("UserName")
                    for (k in user) {
                        if (i.User.equals(k.Id.toString())) {
                            outName = k.Name
                        }
                    }
                    writeString(outName)
                    writeFieldName("Log")
                    writeStartArray()
                    for (i in StorageReg
                        .getAll()
                        .values
                        .filter {
                            it.Equipment == i.Id
                        }.sortedWith(compareByDescending<Reg> { it.LogDateTime }.thenBy { it.Id })) {
                        writeStartObject()
                        writeFieldName("Id")
                        writeString(i.Id.toString())
                        writeFieldName("ResponsiblePerson")
                        writeString(i.ResponsiblePerson.toString())
                        writeFieldName("Operation")
                        writeString(i.Operation)
                        writeFieldName("Text")
                        writeString(i.Text)
                        writeFieldName("LogDateTime")
                        writeString(i.LogDateTime)
                        writeEndObject()
                    }
                    writeEndArray()
                    writeEndObject()
                }
            }
        }
        outputGenerator.close()
        return s
    }

    override fun invoke(request: Request): Response {
        val by: String? = request.path("equipment-id")
        try {
            val list = StorageItem.getAll().values
            val hr = UUID.fromString(by)
            var flag = 0
            if (list.filter { it.Id == hr }.isNotEmpty()) {
                flag = 1
            }
            if (flag == 0) {
                return Response(
                    Status.NOT_FOUND,
                ).contentType(
                    ContentType.APPLICATION_JSON,
                ).body(JSONObject().put("EquipmentId", by).put("Error", "Элемент техники не найден").toString())
            } else {
                return Response(Status.OK).contentType(ContentType.APPLICATION_JSON).body(showEquipment(UUID.fromString(by)).toString())
            }
        } catch (e: Exception) {
            return Response(Status.BAD_REQUEST).contentType(ContentType.APPLICATION_JSON).body(
                JSONObject()
                    .put(
                        "Error",
                        "Некорректный индетификатор техники. Для параметра equipment-id индетификатор техники, но получено значение «$by»",
                    ).toString(),
            )
        }
    }
}
