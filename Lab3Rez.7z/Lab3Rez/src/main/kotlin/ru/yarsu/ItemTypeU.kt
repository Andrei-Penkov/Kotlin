package ru.yarsu

enum class ItemTypeU(
    val type: String,
) {
    Monitor("монитор"),
    PC("ПК"),
    Telephon("телефон"),
    Printer("принтер"),
    Other("другое"),
}
