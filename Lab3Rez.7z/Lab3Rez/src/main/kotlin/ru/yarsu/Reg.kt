package ru.yarsu

import java.util.UUID

data class Reg(
    val Id: UUID,
    val Equipment: UUID,
    val ResponsiblePerson: UUID,
    val Operation: String,
    val Text: String,
    val LogDateTime: String,
)
