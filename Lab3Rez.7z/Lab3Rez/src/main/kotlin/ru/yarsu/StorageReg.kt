package ru.yarsu

import java.util.UUID
import kotlin.collections.HashMap

class StorageReg {
    companion object {
        private var rez: HashMap<UUID, Reg> = HashMap<UUID, Reg>()

        fun stor(a: List<Reg>): HashMap<UUID, Reg> {
            if (rez.isEmpty()) {
                for (i in a) {
                    rez.put(i.Id, i)
                }
            }
            return rez
        }

        fun getAll(): HashMap<UUID, Reg> = rez

        fun getTriangle(id: UUID): Reg? = rez.get(id)

        fun putTriangle(triangle: Reg) {
            rez.put(triangle.Id, triangle)
        }
    }
}
