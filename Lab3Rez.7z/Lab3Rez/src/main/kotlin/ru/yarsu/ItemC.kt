package ru.yarsu

import java.time.LocalDate
import java.util.UUID

data class ItemC(
    val Id: UUID,
    val Equipment: String,
    val Category: String,
    val GuaranteeDate: LocalDate,
    val IsUsed: Boolean,
    val Price: Double,
    val Location: String,
    val ResponsiblePerson: String,
    val User: String? = null,
)
