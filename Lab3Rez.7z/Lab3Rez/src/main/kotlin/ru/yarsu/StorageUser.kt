package ru.yarsu

import ru.yarsu.web.routes.User
import java.util.UUID
import kotlin.collections.HashMap

class StorageUser {
    companion object {
        private var rez: HashMap<UUID, User> = HashMap<UUID, User>()

        fun stor(a: List<User>): HashMap<UUID, User> {
            if (rez.isEmpty()) {
                for (i in a) {
                    rez.put(i.Id, i)
                }
            }
            return rez
        }

        fun getAll(): HashMap<UUID, User> = rez

        fun getTriangle(id: UUID): User? = rez.get(id)

        fun putTriangle(triangle: User) {
            rez.put(triangle.Id, triangle)
        }

        fun deleteTriangle(id: UUID) {
            rez.remove(id)
        }
    }
}
