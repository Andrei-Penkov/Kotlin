plugins {
    kotlin("jvm") version "2.0.20"
    id("ru.yarsu.json-project-properties")
    id("org.jlleitschuh.gradle.ktlint") version "12.1.1"
    kotlin("plugin.serialization") version "2.0.21"
}

group = "ru.ac.uniyar"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    testImplementation(kotlin("test"));
    implementation("org.jcommander:jcommander:2.0");
    implementation("org.http4k:http4k-core:5.32.0.0");
    implementation("org.http4k:http4k-client-apache:5.32.0.0");
    implementation("org.http4k:http4k-server-netty:5.32.0.0");
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3");
    implementation("org.json:json:20231013");
    implementation("com.fasterxml.jackson.module:jackson-module-kotlin:2.17.2");
    implementation("com.google.code.gson:gson:2.8.5");
}

tasks.test {
    useJUnitPlatform()
}

kotlin {
    jvmToolchain(21)
}

ktlint {
    version.set("1.3.1")
}
