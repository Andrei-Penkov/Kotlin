package ru.yarsu
import java.lang.Math.*
import java.time.LocalDateTime
import java.util.*

data class Triangle (val Id: UUID, val SideA: Double, val SideB: Double, val SideC: Double,val RegistrationDateTime: LocalDateTime, val BorderColor: Color, val FillColor: Color, val Description: String) {

    var maxs = max(SideA,max(SideB,SideC))
    var pr = (SideA+SideB+SideC)
    val p = pr()/2
    var space = (sqrt(p*(p-SideA)*(p-SideB)*(p-SideC)))
    var textinfo = "Первая сторона $SideA, вторая сторона $SideB, третья сторона $SideC"

    fun pr(): Double {
        return (SideA+SideB+SideC)
    }

    fun sides(): List<Double>{
        val rez = listOf(SideA,SideB,SideC)
        return rez.sorted()
    }
}
