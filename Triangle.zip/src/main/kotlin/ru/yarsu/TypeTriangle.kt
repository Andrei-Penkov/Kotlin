package ru.yarsu

enum class TypeTriangle (val nameT: String){
    Incorrect("некорректный"),
    Segment("отрезок"),
    Acute_angled("остроугольный"),
    Rectangular("прямоугольный"),
    Obtuse("тупоугольный"),
    ;
}
