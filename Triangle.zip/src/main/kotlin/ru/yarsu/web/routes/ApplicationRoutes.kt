package ru.yarsu.web.routes


import com.fasterxml.jackson.core.JsonFactory
import com.fasterxml.jackson.core.JsonFactoryBuilder
import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.util.DefaultIndenter
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter
import org.http4k.routing.RoutingHttpHandler
import org.http4k.core.*
import org.http4k.lens.contentType
import org.http4k.routing.*
import org.http4k.server.Netty
import org.http4k.server.asServer
import ru.yarsu.*
import ru.yarsu.main
import java.io.File
import kotlinx.serialization.*
import kotlinx.serialization.json.Json
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import org.json.JSONObject
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonElement
import java.io.StringWriter
import java.util.*

data class help(val id:String,val registrationDateTime:String,val description:String)
data class help2(val color: String, val count: String)
data class help21(val statisticByColor: List<String>)

class ApplicationRoutes {

    fun list(file: File): List<String> {
        val rootObject = JSONObject()
        var rez = ""
        val list = createdList(file)
        val jsonArray = mutableListOf<String>()
        if (list.isEmpty()){
            println(list)
            return jsonArray
        }
        val OutputList = list.sortedWith(compareBy({ it.RegistrationDateTime},{ it.Id }))
        val builder = GsonBuilder()
        val gson = builder.create();
        for(i in OutputList){
            val jsonString = Gson().toJson(help(i.Id.toString(),i.RegistrationDateTime.toString(),i.Description))
            jsonArray.add(jsonString)
        }
        return jsonArray
    }

    fun list1(file: File): StringWriter {
//        if(TEXT!="color" && TEXT!="type")
//            exitProcess(1)
        val jsonArray = mutableListOf<String>()
        val TEXT = "color"
        val list = createdList(file)
        var rez = mutableListOf<String>()
        var rez1 = mutableListOf<String>()
        var count1C:Int=0
        var count2C:Int=0
        var count3C:Int=0
        var count4C:Int=0
        var count5C:Int=0
        var count6C:Int=0
        var count7C:Int=0
        var count8C:Int=0
        var count9C:Int=0
        var count1T:Int=0
        var count2T:Int=0
        var count3T:Int=0
        var count4T:Int=0
        var count5T:Int=0
        var count6T:Int=0
        if(TEXT=="color,type"){
            for (i in list){
                when(i.FillColor.nameC){
                    "Фиолетовый" -> count1C++
                    "Индиго" -> count2C++
                    "Синий" -> count3C++
                    "Зеленый" -> count4C++
                    "Желтый" -> count5C++
                    "Оранжевый" -> count6C++
                    "Красный" -> count7C++
                    "Черный" -> count8C++
                    "Белый"-> count9C++
                }
            }
            for (i in list){
                when(i.FillColor.nameC){
                    "Фиолетовый" -> rez.add("PURPLE $count1C")
                    "Индиго" -> rez.add("INDIGO $count2C")
                    "Синий" -> rez.add("BLUE $count3C")
                    "Зеленый" -> rez.add("GREEN $count4C")
                    "Желтый" -> rez.add("YELLOW $count5C")
                    "Оранжевый" -> rez.add("ORANGE $count6C")
                    "Красный" -> rez.add("RED $count7C")
                    "Черный" -> rez.add("BLACK $count8C")
                    "Белый"-> rez.add("WHITE $count9C")
                }
            }
            for (i in list){
                when(i.fe(i).nameT){
                    "некорректный" -> count1T++
                    "отрезок" -> count2T++
                    "остроугольный" -> count3T++
                    "прямоугольный" -> count4T++
                    "тупоугольный" -> count5T++
                }
            }
            for (i in list){
                when(i.fe(i).nameT){
                    "некорректный" -> rez1.add("некорректный $count1T")
                    "отрезок" -> rez1.add("отрезок $count2T")
                    "остроугольный" -> rez1.add("остроугольный $count3T")
                    "прямоугольный" -> rez1.add("прямоугольный $count4T")
                    "тупоугольный" -> rez1.add("тупоугольный $count5T")
                }
            }
        }
        if(TEXT=="color"){
            for (i in list){
                when(i.FillColor.nameC){
                    "Фиолетовый" -> count1C++
                    "Индиго" -> count2C++
                    "Синий" -> count3C++
                    "Зеленый" -> count4C++
                    "Желтый" -> count5C++
                    "Оранжевый" -> count6C++
                    "Красный" -> count7C++
                    "Черный" -> count8C++
                    "Белый"-> count9C++
                }
            }
            for (i in list){
                when(i.FillColor.nameC){
                    "Фиолетовый" -> rez.add("PURPLE $count1C")
                    "Индиго" -> rez.add("INDIGO $count2C")
                    "Синий" -> rez.add("BLUE $count3C")
                    "Зеленый" -> rez.add("GREEN $count4C")
                    "Желтый" -> rez.add("YELLOW $count5C")
                    "Оранжевый" -> rez.add("ORANGE $count6C")
                    "Красный" -> rez.add("RED $count7C")
                    "Черный" -> rez.add("BLACK $count8C")
                    "Белый"-> rez.add("WHITE $count9C")
                }
            }
        }
        val outrez = rez.toSet().toList()
        val outrezsort = outrez.sorted()
        val outrez1 = rez1.toSet().toList()
        val outrez1sort = outrez1.sorted()
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val stringWriter = StringWriter()
        val outputGenerator: JsonGenerator = factory.createGenerator(stringWriter)
        val printer = DefaultPrettyPrinter()
        if (TEXT!="color,type") {
            printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
                if (TEXT == "color")
                    with(outputGenerator) {
                        writeStartObject()
                        if (TEXT == "color")
                            writeFieldName("statisticByColor")
                        writeStartArray()
                        if (TEXT == "color")
                            for (i in outrezsort) {
                                writeStartObject()
                                writeFieldName("color")
                                writeString(i.split(" ")[0])
                                writeFieldName("count")
                                writeString(i.split(" ")[1])
                                writeEndObject()
                            }
                        writeEndArray()
                    }
            outputGenerator.close()
        }
        return stringWriter
    }
    fun rez(file: File): RoutingHttpHandler {
        val web = routes(
            "list-triangles" bind Method.GET to { Response(Status.OK).contentType(ContentType.APPLICATION_JSON).body(list(file).toString()) },
            "statistic-by-color" bind Method.GET to { Response(Status.OK).contentType(ContentType.APPLICATION_JSON).body(list1(file).toString()) }
        )
        val app = routes(
            "ping" bind Method.GET to { Response(Status.OK).body("An application for managing a list of triangles") },
            "v1" bind web
        )
        return app
    }
}
