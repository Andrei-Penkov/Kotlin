package ru.yarsu

import com.beust.jcommander.Parameter
import com.beust.jcommander.Parameters
import com.fasterxml.jackson.core.JsonFactory
import com.fasterxml.jackson.core.JsonFactoryBuilder
import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.util.DefaultIndenter
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.UUID
import kotlin.system.exitProcess

@Parameters (separators = "=")
class Args {
    @Parameter(names = ["--triangles-file"], description = "Input file")
    var inputFile: String? = null
    @Parameter(names = ["--port"], description = "Input port")
    var port: String? = null
}
@Parameters(commandNames = ["list"], separators = "=")
class ListCommand {
    @Parameter(
        names = ["--triangles-file"], required = true,
    )
    var FILE: String? = null
    fun list(){
        val list = createdList(File(FILE.toString()))
        if (list.isEmpty()){
            println(list)
            return
        }
        val OutputList = list.sortedWith(compareBy({ it.RegistrationDateTime},{ it.Id }))
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val outputGenerator: JsonGenerator = factory.createGenerator(System.out)
        val printer = DefaultPrettyPrinter()
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        with(outputGenerator){
            writeStartObject()
            writeFieldName("triangles")
            writeStartArray()
            for(i in OutputList){
                writeStartObject()
                writeFieldName("description")
                writeString(i.Description)
                writeFieldName("id")
                writeString(i.Id.toString())
                writeFieldName("registrationDateTime")
                writeString(i.RegistrationDateTime.toString())
                writeEndObject()
            }
            writeEndArray()
        }
        outputGenerator.close()
    }
}

@Parameters(commandNames = ["show"], separators = "=")
class ShowCommand {
    @Parameter(
        names = ["--id"], required = true,
    )
    var TEXT: String? = null
    @Parameter(
        names = ["--triangles-file"], required = true,
    )
    var FILE: String? = null

    fun list(){
        val list = createdList(File(FILE.toString()))
        if (list.isEmpty()){
            println(list)
            return
        }
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val outputGenerator: JsonGenerator = factory.createGenerator(System.out)
        val printer = DefaultPrettyPrinter()
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        with(outputGenerator){
            writeStartObject()
            writeFieldName("id")
            writeString(TEXT)
            writeFieldName("triangle")
            for(i in list){
                if(i.Id.equals(UUID.fromString(TEXT))){
                    writeStartObject()
                    writeFieldName("borderColor")
                    writeString(i.BorderColor.toString())
                    writeFieldName("description")
                    writeString(i.Description)
                    writeFieldName("id")
                    writeString(i.Id.toString())
                    writeFieldName("registrationDateTime")
                    writeString(i.RegistrationDateTime.toString())
                    writeFieldName("sideA")
                    writeString(i.SideA.toString())
                    writeFieldName("sideB")
                    writeString(i.SideB.toString())
                    writeFieldName("sideA")
                    writeString(i.SideC.toString())
                    writeFieldName("area")
                    if(i.fe(i).equals(TypeTriangle.Incorrect)){
                        writeNull()
                    }
                    else{
                        writeString(i.space.toString())
                    }
                    writeFieldName("type")
                    writeString(i.fe(i).nameT)
                    writeEndObject()
                }

            }
        }
        outputGenerator.close()
    }
}

@Parameters(commandNames = ["list-color"], separators = "=")
class InfoCommand {
    @Parameter(
        names = ["--border-color"], required = true
    )
    var TEXT: String? = null
    @Parameter(
        names = ["--triangles-file"], required = true,
    )
    var FILE: String? = null

    fun list(){
        val list = createdList(File(FILE.toString()))
        val rez = mutableListOf<Triangle>()
        if (list.isEmpty()){
            println(list)
            return
        }
        for(i in list){
            if (i.BorderColor.toString().lowercase() == TEXT.toString().lowercase())
                rez.add(i)
        }
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val outputGenerator: JsonGenerator = factory.createGenerator(System.out)
        val printer = DefaultPrettyPrinter()
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        with(outputGenerator){
            writeStartObject()
                writeFieldName("BorderColor")
                writeString(TEXT)
                writeFieldName("triangles")
                writeStartArray()
                for(i in rez){
                    writeStartObject()
                    writeFieldName("id")
                    writeString(i.Id.toString())
                    writeFieldName("sideA")
                    writeString(i.SideA.toString())
                    writeFieldName("sideB")
                    writeString(i.SideB.toString())
                    writeFieldName("sideA")
                    writeString(i.SideC.toString())
                    writeEndObject()
                }
                writeEndArray()
        }
        outputGenerator.close()
    }
}

@Parameters(commandNames = ["list-area"], separators = "=")
class AreaCommand {
    @Parameter(
        names = ["--area-min"]
    )
    var TEXT: String? = null
    @Parameter(
        names = ["--area-max"]
    )
    var TEXT1: String? = null
    @Parameter(
        names = ["--triangles-file"], required = true,
    )
    var FILE: String? = null
    fun list(){
        if(TEXT == null && TEXT1 == null)
            exitProcess(1)
        val list = createdList(File(FILE.toString()))
        val rez = mutableListOf<Triangle>()
        if (list.isEmpty()){
            println(list)
            return
        }
        for(i in list){
            if (TEXT!=null && TEXT1!=null){
                if (i.space >= TEXT!!.toDouble() && i.space <= TEXT1!!.toDouble())
                    rez.add(i)
            }

            else if (TEXT!=null){
                if (i.space >= TEXT!!.toDouble())
                    rez.add(i)
            }

            else if (TEXT1!=null){
                if (i.space <= TEXT1!!.toDouble())
                    rez.add(i)
            }

        }
        val rezrez = rez.sortedWith(compareBy({ it.RegistrationDateTime},{ it.Id }))
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val outputGenerator: JsonGenerator = factory.createGenerator(System.out)
        val printer = DefaultPrettyPrinter()
        printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
        outputGenerator.prettyPrinter = printer
        with(outputGenerator){
            writeStartObject()
            if(TEXT!=null){
                writeFieldName("AreaMin")
                writeNumber(TEXT!!.toDouble())
            }
            if(TEXT1!=null){
                writeFieldName("AreaMax")
                writeNumber(TEXT1!!.toDouble())
            }
            writeFieldName("triangles")
            writeStartArray()
            for(i in rezrez){
                writeStartObject()
                writeFieldName("id")
                writeString(i.Id.toString())
                writeFieldName("sideA")
                writeString(i.SideA.toString())
                writeFieldName("sideB")
                writeString(i.SideB.toString())
                writeFieldName("sideA")
                writeString(i.SideC.toString())
                writeEndObject()
            }
            writeEndArray()
        }
        outputGenerator.close()
    }
}

@Parameters(commandNames = ["statistic"], separators = "=")
class StaticCommand {
    @Parameter(
        names = ["--by"], required = true
    )
    var TEXT: String? = null
    @Parameter(
        names = ["--triangles-file"], required = true,
    )
    var FILE: String? = null
    fun list(){
//        if(TEXT!="color" && TEXT!="type")
//            exitProcess(1)
        val list = createdList(File(FILE.toString()))
        var rez = mutableListOf<String>()
        var rez1 = mutableListOf<String>()
        if (list.isEmpty()){
            println(list)
            return
        }
        var count1C:Int=0
        var count2C:Int=0
        var count3C:Int=0
        var count4C:Int=0
        var count5C:Int=0
        var count6C:Int=0
        var count7C:Int=0
        var count8C:Int=0
        var count9C:Int=0
        var count1T:Int=0
        var count2T:Int=0
        var count3T:Int=0
        var count4T:Int=0
        var count5T:Int=0
        var count6T:Int=0
        if(TEXT=="color,type"){
            for (i in list){
                when(i.FillColor.nameC){
                    "Фиолетовый" -> count1C++
                    "Индиго" -> count2C++
                    "Синий" -> count3C++
                    "Зеленый" -> count4C++
                    "Желтый" -> count5C++
                    "Оранжевый" -> count6C++
                    "Красный" -> count7C++
                    "Черный" -> count8C++
                    "Белый"-> count9C++
                }
            }
            for (i in list){
                when(i.FillColor.nameC){
                    "Фиолетовый" -> rez.add("PURPLE $count1C")
                    "Индиго" -> rez.add("INDIGO $count2C")
                    "Синий" -> rez.add("BLUE $count3C")
                    "Зеленый" -> rez.add("GREEN $count4C")
                    "Желтый" -> rez.add("YELLOW $count5C")
                    "Оранжевый" -> rez.add("ORANGE $count6C")
                    "Красный" -> rez.add("RED $count7C")
                    "Черный" -> rez.add("BLACK $count8C")
                    "Белый"-> rez.add("WHITE $count9C")
                }
            }
            for (i in list){
                when(i.fe(i).nameT){
                    "некорректный" -> count1T++
                    "отрезок" -> count2T++
                    "остроугольный" -> count3T++
                    "прямоугольный" -> count4T++
                    "тупоугольный" -> count5T++
                }
            }
            for (i in list){
                when(i.fe(i).nameT){
                    "некорректный" -> rez1.add("некорректный $count1T")
                    "отрезок" -> rez1.add("отрезок $count2T")
                    "остроугольный" -> rez1.add("остроугольный $count3T")
                    "прямоугольный" -> rez1.add("прямоугольный $count4T")
                    "тупоугольный" -> rez1.add("тупоугольный $count5T")
                }
            }
        }
        if(TEXT=="color"){
            for (i in list){
                when(i.FillColor.nameC){
                    "Фиолетовый" -> count1C++
                    "Индиго" -> count2C++
                    "Синий" -> count3C++
                    "Зеленый" -> count4C++
                    "Желтый" -> count5C++
                    "Оранжевый" -> count6C++
                    "Красный" -> count7C++
                    "Черный" -> count8C++
                    "Белый"-> count9C++
                }
            }
            for (i in list){
                when(i.FillColor.nameC){
                    "Фиолетовый" -> rez.add("PURPLE $count1C")
                    "Индиго" -> rez.add("INDIGO $count2C")
                    "Синий" -> rez.add("BLUE $count3C")
                    "Зеленый" -> rez.add("GREEN $count4C")
                    "Желтый" -> rez.add("YELLOW $count5C")
                    "Оранжевый" -> rez.add("ORANGE $count6C")
                    "Красный" -> rez.add("RED $count7C")
                    "Черный" -> rez.add("BLACK $count8C")
                    "Белый"-> rez.add("WHITE $count9C")
                }
            }
        }
        val outrez = rez.toSet().toList()
        val outrezsort = outrez.sorted()
        for(i in outrez)
            println(i)
        if(TEXT=="type"){
            for (i in list){
                when(i.fe(i).nameT){
                    "некорректный" -> count1T++
                    "отрезок" -> count2T++
                    "остроугольный" -> count3T++
                    "прямоугольный" -> count4T++
                    "тупоугольный" -> count5T++
                }
            }
            for (i in list){
                when(i.fe(i).nameT){
                    "некорректный" -> rez1.add("некорректный $count1T")
                    "отрезок" -> rez1.add("отрезок $count2T")
                    "остроугольный" -> rez1.add("остроугольный $count3T")
                    "прямоугольный" -> rez1.add("прямоугольный $count4T")
                    "тупоугольный" -> rez1.add("тупоугольный $count5T")
                }
            }
        }
        val outrez1 = rez1.toSet().toList()
        val outrez1sort = outrez1.sorted()
        val factory: JsonFactory = JsonFactoryBuilder().build()
        val outputGenerator: JsonGenerator = factory.createGenerator(System.out)
        val printer = DefaultPrettyPrinter()
        if (TEXT!="color,type") {
            printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
            outputGenerator.prettyPrinter = printer
            with(outputGenerator) {
                writeStartObject()
                if (TEXT == "color")
                    writeFieldName("statisticByColor")
                else
                    writeFieldName("statisticByType")
                writeStartArray()
                if (TEXT == "color")
                    for (i in outrezsort) {
                        writeStartObject()
                        writeFieldName("color")
                        writeString(i.split(" ")[0])
                        writeFieldName("count")
                        writeString(i.split(" ")[1])
                        writeEndObject()
                    }
                if (TEXT == "type")
                    for (i in outrez1sort) {
                        writeStartObject()
                        writeFieldName("type")
                        writeString(i.split(" ")[0])
                        writeFieldName("count")
                        writeString(i.split(" ")[1])
                        writeEndObject()
                    }
                writeEndArray()
            }
            outputGenerator.close()
        }
        else
        {
            printer.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE)
            outputGenerator.prettyPrinter = printer
            with(outputGenerator){
                writeStartObject()
                writeFieldName("statisticByColor")
                writeStartArray()
                for(i in outrezsort){
                    writeStartObject()
                    writeFieldName("color")
                    writeString(i.split(" ")[0])
                    writeFieldName("count")
                    writeString(i.split(" ")[1])
                    writeEndObject()
                }
                writeEndArray()

                writeFieldName("statisticByType")
                writeStartArray()
                for(i in outrez1sort) {
                    writeStartObject()
                    writeFieldName("type")
                    writeString(i.split(" ")[0])
                    writeFieldName("count")
                    writeString(i.split(" ")[1])
                    writeEndObject()
                }
                writeEndArray()
            }
            outputGenerator.close()
        }
    }
}
