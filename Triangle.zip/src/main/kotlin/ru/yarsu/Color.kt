package ru.yarsu

enum class Color(val nameC: String) {
    Purple("Фиолетовый"),
    Indigo("Индиго"),
    Blue("Синий"),
    Green("Зеленый"),
    Yellow("Желтый"),
    Orange("Оранжевый"),
    Red("Красный"),
    Black("Черный"),
    White("Белый"),
    ;
}
