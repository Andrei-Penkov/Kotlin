package ru.yarsu

import com.beust.jcommander.JCommander
import com.github.doyaaaaaken.kotlincsv.dsl.csvReader
import org.http4k.core.*
import org.http4k.server.Netty
import org.http4k.server.asServer
import java.io.File
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.math.pow
import kotlin.system.exitProcess
import ru.yarsu.web.routes.ApplicationRoutes

typealias HttpHandler = (Request) -> Response

fun Triangle.fe(triangle: Triangle):TypeTriangle{
    val list = triangle.sides()
    val maxind = list.indexOf(triangle.maxs)
    var sym = 0.0
    var symqrt = 0.0
    list.forEach(){
        if (list.indexOf(it) != maxind)
        {
            sym += it
            symqrt += it.pow(2)
        }

    }
    if (triangle.maxs > sym)
        return(TypeTriangle.Incorrect)
    else if (triangle.maxs == sym)
        return (TypeTriangle.Segment)
    else if (triangle.maxs.pow(2) < symqrt)
        return (TypeTriangle.Acute_angled)
    else if (triangle.maxs.pow(2) == symqrt)
        return (TypeTriangle.Rectangular)
    else
        return(TypeTriangle.Obtuse)
}

fun createdList(file:File):List<Triangle>{
    val list = csvReader().readAll(file)
    val rez = mutableListOf<Triangle>()
    var count = 0
    for(i in list){
        if(count==0){
            count++
            continue
        }
        var r = Color.Red
        when(i[5]){
            "RED" -> r = Color.Red
            "GREEN" -> r = Color.Green
            "PURPLE" -> r = Color.Purple
            "INDIGO" -> r = Color.Indigo
            "BLUE" -> r = Color.Blue
            "YELLOW" -> r = Color.Yellow
            "ORANGE" -> r = Color.Orange
            "BLACK" -> r = Color.Black
            "WHITE" -> r = Color.White
        }
        var r1 = Color.Red
        when(i[6]){
            "RED" -> r1 = Color.Red
            "GREEN" -> r1 = Color.Green
            "PURPLE" -> r1 = Color.Purple
            "INDIGO" -> r1 = Color.Indigo
            "BLUE" -> r1 = Color.Blue
            "YELLOW" -> r1 = Color.Yellow
            "ORANGE" -> r1 = Color.Orange
            "BLACK" -> r1 = Color.Black
            "WHITE" -> r1 = Color.White
        }
        rez.add(Triangle(UUID.fromString(i[0]),i[1].toDouble(),i[2].toDouble(),i[3].toDouble(),LocalDateTime.parse(i[4]),r,r1,i[7]))
    }
    return rez
}
fun main(args: Array<String>) {
    val argObj = Args()
    val builder =  JCommander.newBuilder().addObject(argObj)
    val listCommand = ListCommand()
    val infoCommand = InfoCommand()
    val showCommand = ShowCommand()
    val areaCommand = AreaCommand()
    val staticCommand = StaticCommand()
    builder.addCommand("list",listCommand)
    builder.addCommand("list-color",infoCommand)
    builder.addCommand("show", showCommand)
    builder.addCommand("list-area", areaCommand)
    builder.addCommand("statistic", staticCommand)
    val jCommander = builder.build()
    try {
        jCommander.parse(*args)
        when(jCommander.parsedCommand){
            "list" -> listCommand.list()
            "list-color" -> infoCommand.list()
            "show" -> showCommand.list()
            "list-area" -> areaCommand.list()
            "statistic" -> staticCommand.list()
            else -> {
                val file = File(argObj.inputFile)
                val input = createdList(file)
                val port = argObj.port
                val response = ApplicationRoutes().rez(file)
//                val handler: HttpHandler = { request: Request -> response }
                val jettyServer = response.asServer(Netty(9000)).start()
            }
        }
    } catch (e: Exception) {
        jCommander.usage()
        exitProcess(1)
    }
}
